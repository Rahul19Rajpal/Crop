import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart3, Cloud, Database, LineChart, Users } from "lucide-react"
import Image from "next/image"

export default function FeaturesPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">System Features</h1>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Explore the comprehensive features of our Community-Driven Crop Yield Prediction and Optimization System
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Tabs Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container mx-auto px-4 md:px-6">
          <Tabs defaultValue="data-collection" className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
              <TabsTrigger value="data-collection">Data Collection</TabsTrigger>
              <TabsTrigger value="prediction">Prediction Analysis</TabsTrigger>
              <TabsTrigger value="optimization">Optimization Engine</TabsTrigger>
              <TabsTrigger value="community">Community Platform</TabsTrigger>
              <TabsTrigger value="reporting">Reporting</TabsTrigger>
            </TabsList>
            <TabsContent value="data-collection" className="mt-6">
              <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
                <div className="flex flex-col justify-center space-y-4">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Data Collection and Processing</h2>
                    <p className="text-muted-foreground md:text-xl">
                      Capture and store diverse agricultural data from various sources
                    </p>
                  </div>
                  <div className="space-y-4 text-muted-foreground">
                    <p>
                      Our data collection module enables users to input, import, and manage agricultural data from
                      various sources. This feature is essential for building the foundation of the prediction and
                      optimization system.
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Manual data entry forms for agricultural information</li>
                      <li>Integration with weather APIs for automatic updates</li>
                      <li>Mobile interface for field data collection with offline capabilities</li>
                      <li>Data validation rules to ensure accuracy</li>
                      <li>Support for bulk import of historical data</li>
                      <li>Organization by location, crop type, and growing season</li>
                    </ul>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <div className="relative h-[400px] w-full overflow-hidden rounded-xl">
                    <Image
                      src="https://d2ds8yldqp7gxv.cloudfront.net/Blog+Explanatory+Images/Data+Collection+Methods+2.webp"
                      alt="Data Collect Interface"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="prediction" className="mt-6">
              <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
                <div className="flex flex-col justify-center space-y-4">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Prediction Analysis</h2>
                    <p className="text-muted-foreground md:text-xl">
                      Machine learning algorithms to predict crop yields with confidence levels
                    </p>
                  </div>
                  <div className="space-y-4 text-muted-foreground">
                    <p>
                      Our prediction analysis feature uses machine learning algorithms to analyze collected data and
                      generate crop yield predictions based on various factors including weather patterns, soil
                      conditions, and farming practices.
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Advanced machine learning models for accurate predictions</li>
                      <li>Confidence levels for all yield forecasts</li>
                      <li>Identification of key factors influencing predictions</li>
                      <li>Automatic updates when new data is received</li>
                      <li>Support for multiple crop types relevant to local communities</li>
                      <li>Comparison tools for different scenarios</li>
                    </ul>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <div className="relative h-[400px] w-full overflow-hidden rounded-xl">
                    <Image
                      src="https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?q=80&w=2076&auto=format&fit=crop"
                      alt="Prediction Analysis Dashboard"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="optimization" className="mt-6">
              <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
                <div className="flex flex-col justify-center space-y-4">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Optimization Engine</h2>
                    <p className="text-muted-foreground md:text-xl">
                      Recommendations for maximizing yield and minimizing resource usage
                    </p>
                  </div>
                  <div className="space-y-4 text-muted-foreground">
                    <p>
                      The optimization engine provides recommendations for agricultural practices to maximize crop
                      yield, minimize resource usage, and reduce environmental impact based on predictive analysis and
                      local conditions.
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Optimal planting time recommendations based on weather forecasts</li>
                      <li>Resource allocation guidance for water, fertilizer, and pest control</li>
                      <li>Multiple optimization scenarios for different goals</li>
                      <li>Implementation tracking for continuous improvement</li>
                      <li>Risk identification and mitigation strategies</li>
                      <li>Long-term soil health and crop rotation recommendations</li>
                    </ul>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <div className="relative h-[400px] w-full overflow-hidden rounded-xl">
                    <Image
                      src="https://ibmdecisionoptimization.github.io/docplex-doc/2.23.222/_images/ln_docloud-engine.png"
                      alt="Optimization Recommendations"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="community" className="mt-6">
              <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
                <div className="flex flex-col justify-center space-y-4">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">
                      Community Collaboration Platform
                    </h2>
                    <p className="text-muted-foreground md:text-xl">
                      Knowledge sharing and collective decision-making among agricultural stakeholders
                    </p>
                  </div>
                  <div className="space-y-4 text-muted-foreground">
                    <p>
                      The community collaboration platform enables knowledge sharing, discussion, and collective
                      decision-making among different user groups in the agricultural community.
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Discussion forums organized by topic and region</li>
                      <li>Documentation of successful farming practices</li>
                      <li>Q&A system for community support</li>
                      <li>Coordination tools for community leaders</li>
                      <li>Notification system for relevant updates</li>
                      <li>Reputation system to identify reliable information sources</li>
                    </ul>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <div className="relative h-[400px] w-full overflow-hidden rounded-xl">
                    <Image
                      src="https://images.unsplash.com/photo-1531973486364-5fa64260d75b?q=80&w=2069&auto=format&fit=crop"
                      alt="Community Collaboration Platform"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="reporting" className="mt-6">
              <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
                <div className="flex flex-col justify-center space-y-4">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Reporting and Visualization</h2>
                    <p className="text-muted-foreground md:text-xl">
                      Interactive dashboards and comprehensive reports for data-driven insights
                    </p>
                  </div>
                  <div className="space-y-4 text-muted-foreground">
                    <p>
                      The reporting and visualization feature provides tools for generating insights from collected
                      data, visualizing trends, and creating reports for different stakeholder groups.
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Customized dashboards for different user roles</li>
                      <li>Comprehensive reports on agricultural performance</li>
                      <li>Interactive visualization tools for data exploration</li>
                      <li>Export options in multiple formats</li>
                      <li>Trend analysis for key metrics over time</li>
                      <li>Aggregate views for community and government planning</li>
                    </ul>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <div className="relative h-[400px] w-full overflow-hidden rounded-xl">
                    <Image
                      src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2015&auto=format&fit=crop"
                      alt="Reporting Dashboard"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Feature Cards Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Key System Components</h2>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Explore the comprehensive features that make our platform powerful and user-friendly
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center gap-2">
                <Database className="h-6 w-6 text-primary" />
                <CardTitle>Data Collection Module</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Capture and store diverse agricultural data (soil, weather, crop history, etc.), integrate with
                  external data sources and APIs, and validate and clean submitted data.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center gap-2">
                <LineChart className="h-6 w-6 text-primary" />
                <CardTitle>Prediction Engine</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Apply machine learning algorithms to predict crop yields, consider multiple variables, and provide
                  confidence levels for predictions.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center gap-2">
                <BarChart3 className="h-6 w-6 text-primary" />
                <CardTitle>Optimization Module</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Suggest optimal planting schedules, recommend resource allocation, and identify risk factors and
                  mitigation strategies.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center gap-2">
                <Users className="h-6 w-6 text-primary" />
                <CardTitle>Community Collaboration Platform</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Enable knowledge sharing among farmers, facilitate expert consultations, and promote best practices
                  based on community experiences.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center gap-2">
                <Cloud className="h-6 w-6 text-primary" />
                <CardTitle>External Interfaces</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Connect with weather data APIs, GIS systems, agricultural databases, and machine learning frameworks
                  for comprehensive data integration.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center gap-2">
                <BarChart3 className="h-6 w-6 text-primary" />
                <CardTitle>Reporting and Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Generate insightful reports on agricultural trends, visualize data through interactive dashboards, and
                  support policy-making with evidence-based insights.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
