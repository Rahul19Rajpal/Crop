"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { useToast } from "@/components/ui/use-toast"
import Image from "next/image"

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // In a real app, you would call an API to send a password reset email
      setIsSubmitted(true)
      toast({
        title: "Reset Email Sent",
        description: "Check your inbox for instructions to reset your password.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center bg-gradient-to-b from-green-50 to-white dark:from-green-950/30 dark:to-background p-4">
      <div className="grid w-full max-w-5xl gap-6 lg:grid-cols-2">
        <div className="hidden lg:flex flex-col justify-center space-y-6 rounded-lg bg-green-100/50 dark:bg-green-900/20 p-8">
          <div className="relative h-60 w-full overflow-hidden rounded-lg">
            <Image
              src="https://images.unsplash.com/photo-1590682680695-43b964a3ae17?q=80&w=2070&auto=format&fit=crop"
              alt="Forgot password"
              fill
              className="object-cover"
            />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-bold">Forgot Your Password?</h2>
            <p className="text-muted-foreground">
              No worries! It happens to the best of us. Enter your email address and we'll send you instructions to
              reset your password.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold">Remember your password?</h3>
            <p className="text-sm text-muted-foreground">
              If you suddenly remembered your password, you can{" "}
              <Link href="/login" className="text-primary hover:underline">
                log in here
              </Link>
              .
            </p>
          </div>
        </div>
        <Card className="border-green-100 dark:border-green-900/50">
          {!isSubmitted ? (
            <>
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl font-bold">Forgot Password</CardTitle>
                <CardDescription>Enter your email to receive a password reset link</CardDescription>
              </CardHeader>
              <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="name@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col space-y-4">
                  <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? "Sending..." : "Send Reset Link"}
                  </Button>
                  <div className="text-center text-sm">
                    Remember your password?{" "}
                    <Link href="/login" className="text-primary hover:underline">
                      Back to Login
                    </Link>
                  </div>
                </CardFooter>
              </form>
            </>
          ) : (
            <>
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl font-bold">Check Your Email</CardTitle>
                <CardDescription>We've sent a password reset link to your email</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-lg bg-green-50 dark:bg-green-900/20 p-4 text-center">
                  <p className="text-sm text-muted-foreground">
                    If <span className="font-medium">{email}</span> is associated with an account, you'll receive an
                    email with instructions to reset your password.
                  </p>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col space-y-4">
                <Button variant="outline" className="w-full" onClick={() => setIsSubmitted(false)}>
                  Try Another Email
                </Button>
                <div className="text-center text-sm">
                  Didn't receive the email?{" "}
                  <Button variant="link" className="p-0 h-auto" onClick={() => setIsSubmitted(false)}>
                    Resend
                  </Button>
                </div>
              </CardFooter>
            </>
          )}
        </Card>
      </div>
    </div>
  )
}
