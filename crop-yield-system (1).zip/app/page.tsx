import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, BarChart3, Cloud, Database, LineChart, Users } from "lucide-react"
import Image from "next/image"

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative w-full py-12 md:py-24 lg:py-32 xl:py-48 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image
            src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=2832&auto=format&fit=crop"
            alt="Farm field"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/70 to-background/30 dark:from-background/95 dark:via-background/90 dark:to-background/80" />
        </div>
        <div className="container relative z-10 mx-auto px-4 md:px-6">
          <div className="flex flex-col items-start space-y-4 text-left max-w-[700px]">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                Community-Driven Crop Yield Prediction
              </h1>
              <p className="text-muted-foreground md:text-xl">
                Empowering farmers with data-driven insights for improved agricultural outcomes
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button asChild size="lg" className="bg-green-600 hover:bg-green-700 text-white">
                <Link href="/register">Get Started</Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/features">Learn More</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-green-50 to-white dark:from-green-950/30 dark:to-background">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-green-600 px-3 py-1 text-sm text-white">Key Features</div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Comprehensive Agricultural Management</h2>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Our platform provides a complete solution for agricultural planning and optimization
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
            <Card className="border-green-100 dark:border-green-900/50 hover:shadow-md transition-all">
              <CardHeader className="flex flex-row items-center gap-2">
                <Database className="h-6 w-6 text-green-600" />
                <CardTitle>Data Collection</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Capture and store diverse agricultural data including soil conditions, weather patterns, and
                  historical yield information.
                </CardDescription>
              </CardContent>
            </Card>
            <Card className="border-green-100 dark:border-green-900/50 hover:shadow-md transition-all">
              <CardHeader className="flex flex-row items-center gap-2">
                <LineChart className="h-6 w-6 text-green-600" />
                <CardTitle>Prediction Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Leverage machine learning algorithms to predict crop yields based on multiple variables with
                  confidence levels.
                </CardDescription>
              </CardContent>
            </Card>
            <Card className="border-green-100 dark:border-green-900/50 hover:shadow-md transition-all">
              <CardHeader className="flex flex-row items-center gap-2">
                <BarChart3 className="h-6 w-6 text-green-600" />
                <CardTitle>Optimization Engine</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Receive recommendations for optimal planting schedules, resource allocation, and risk mitigation
                  strategies.
                </CardDescription>
              </CardContent>
            </Card>
            <Card className="border-green-100 dark:border-green-900/50 hover:shadow-md transition-all">
              <CardHeader className="flex flex-row items-center gap-2">
                <Users className="h-6 w-6 text-green-600" />
                <CardTitle>Community Collaboration</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Share knowledge, discuss best practices, and collaborate with other farmers and agricultural experts.
                </CardDescription>
              </CardContent>
            </Card>
            <Card className="border-green-100 dark:border-green-900/50 hover:shadow-md transition-all">
              <CardHeader className="flex flex-row items-center gap-2">
                <Cloud className="h-6 w-6 text-green-600" />
                <CardTitle>Weather Integration</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Automatically integrate weather data and forecasts to improve prediction accuracy and planning.
                </CardDescription>
              </CardContent>
            </Card>
            <Card className="border-green-100 dark:border-green-900/50 hover:shadow-md transition-all">
              <CardHeader className="flex flex-row items-center gap-2">
                <BarChart3 className="h-6 w-6 text-green-600" />
                <CardTitle>Reporting & Visualization</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Generate insightful reports and visualize data through interactive dashboards for better
                  decision-making.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
          <div className="flex justify-center">
            <Button asChild className="bg-green-600 hover:bg-green-700 text-white">
              <Link href="/features">
                Explore All Features <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* User Classes Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-green-600 px-3 py-1 text-sm text-white">For Everyone</div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">
                Designed for All Agricultural Stakeholders
              </h2>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Our platform serves the needs of diverse user groups in the agricultural community
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 py-12 md:grid-cols-2 lg:grid-cols-3">
            <div className="flex flex-col items-center space-y-2 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                <Users className="h-8 w-8 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-xl font-bold">Local Farmers</h3>
              <p className="text-muted-foreground">
                Input data and receive personalized recommendations for improved crop yields
              </p>
            </div>
            <div className="flex flex-col items-center space-y-2 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                <Users className="h-8 w-8 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-xl font-bold">Agricultural Consultants</h3>
              <p className="text-muted-foreground">Provide specialized knowledge and validate system recommendations</p>
            </div>
            <div className="flex flex-col items-center space-y-2 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                <Users className="h-8 w-8 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-xl font-bold">Community Leaders</h3>
              <p className="text-muted-foreground">
                Coordinate community-wide agricultural initiatives and resource planning
              </p>
            </div>
            <div className="flex flex-col items-center space-y-2 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                <Users className="h-8 w-8 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-xl font-bold">Government Agencies</h3>
              <p className="text-muted-foreground">
                Access high-level reports and regional analysis for policy formulation
              </p>
            </div>
            <div className="flex flex-col items-center space-y-2 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                <Users className="h-8 w-8 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-xl font-bold">Data Scientists</h3>
              <p className="text-muted-foreground">
                Maintain and improve prediction models and analyze agricultural trends
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-green-600 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">
                Ready to Transform Your Agricultural Practices?
              </h2>
              <p className="mx-auto max-w-[700px] md:text-xl">
                Join our community of farmers, experts, and agricultural stakeholders today
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button size="lg" variant="secondary" asChild>
                <Link href="/register">Get Started</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-transparent border-white text-white hover:bg-white/10"
                asChild
              >
                <Link href="/contact">Contact Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
