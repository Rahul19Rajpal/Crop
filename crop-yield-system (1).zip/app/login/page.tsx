"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { useAuth } from "@/components/auth-provider"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"
import Image from "next/image"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { login } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const success = await login(email, password)

      if (success) {
        toast({
          title: "Login successful",
          description: "Welcome back to AgriPredict!",
        })
        router.push("/dashboard")
      } else {
        toast({
          title: "Login failed",
          description: "Please check your credentials and try again.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Login error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center bg-gradient-to-b from-green-50 to-white dark:from-green-950/30 dark:to-background p-4">
      <div className="grid w-full max-w-5xl gap-6 lg:grid-cols-2">
        <div className="hidden lg:flex flex-col justify-center space-y-6 rounded-lg bg-green-100/50 dark:bg-green-900/20 p-8">
          <div className="relative h-60 w-full overflow-hidden rounded-lg">
            <Image
              src="https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?q=80&w=2070&auto=format&fit=crop"
              alt="Farming field"
              fill
              className="object-cover"
            />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-bold">Welcome to AgriPredict</h2>
            <p className="text-muted-foreground">
              Log in to access your personalized agricultural insights, predictions, and community resources.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold">Demo Accounts:</h3>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>Farmer: farmer@example.com</li>
              <li>Consultant: consultant@example.com</li>
              <li>Community Leader: leader@example.com</li>
              <li>Government: gov@example.com</li>
              <li>Data Scientist: scientist@example.com</li>
            </ul>
            <p className="text-xs text-muted-foreground">(Use any password for demo purposes)</p>
          </div>
        </div>
        <Card className="border-green-100 dark:border-green-900/50">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold">Login</CardTitle>
            <CardDescription>Enter your email and password to access your account</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <Link href="/forgot-password" className="text-xs text-primary hover:underline">
                    Forgot password?
                  </Link>
                </div>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Logging in..." : "Login"}
              </Button>
              <div className="text-center text-sm">
                Don&apos;t have an account?{" "}
                <Link href="/register" className="text-primary hover:underline">
                  Register
                </Link>
              </div>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  )
}
