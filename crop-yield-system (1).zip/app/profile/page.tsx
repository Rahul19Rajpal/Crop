"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useAuth } from "@/components/auth-provider"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"

// Import the useLanguage hook
import { useLanguage } from "@/components/language-provider"

export default function ProfilePage() {
  const { user, isLoading, logout } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  // Add the useLanguage hook to the component
  const { language, setLanguage, t } = useLanguage()

  const [profileData, setProfileData] = useState({
    name: "",
    email: "",
    role: "",
    phone: "",
    address: "",
    bio: "",
  })

  const [notificationSettings, setNotificationSettings] = useState({
    email: true,
    push: true,
    weatherAlerts: true,
    soilConditions: true,
    marketPrices: false,
    communityUpdates: true,
  })

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  // Load profile data from localStorage
  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Authentication required",
        description: "Please log in to access your profile.",
        variant: "destructive",
      })
      router.push("/login")
      return
    }

    if (user) {
      // Load profile data
      const savedProfile = localStorage.getItem(`profile_${user.id}`)
      if (savedProfile) {
        setProfileData(JSON.parse(savedProfile))
      } else {
        setProfileData({
          name: user.name || "",
          email: user.email || "",
          role: user.role || "",
          phone: "",
          address: "",
          bio: "",
        })
      }

      // Load notification settings
      const savedSettings = localStorage.getItem(`notifications_${user.id}`)
      if (savedSettings) {
        setNotificationSettings(JSON.parse(savedSettings))
      }
    }
  }, [user, isLoading, router, toast])

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target
    setProfileData((prev) => ({ ...prev, [id]: value }))
  }

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target
    setPasswordData((prev) => ({ ...prev, [id]: value }))
  }

  const handleNotificationChange = (key: string, value: boolean) => {
    setNotificationSettings((prev) => ({ ...prev, [key]: value }))
  }

  const handleRoleChange = (value: string) => {
    setProfileData((prev) => ({ ...prev, role: value }))
  }

  const saveProfile = () => {
    if (user) {
      localStorage.setItem(`profile_${user.id}`, JSON.stringify(profileData))
      toast({
        title: "Profile Updated",
        description: "Your profile information has been saved.",
      })
    }
  }

  const saveNotifications = () => {
    if (user) {
      localStorage.setItem(`notifications_${user.id}`, JSON.stringify(notificationSettings))
      toast({
        title: "Notification Settings Updated",
        description: "Your notification preferences have been saved.",
      })
    }
  }

  const changePassword = () => {
    // Validate passwords
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Passwords Don't Match",
        description: "New password and confirmation must match.",
        variant: "destructive",
      })
      return
    }

    if (passwordData.newPassword.length < 6) {
      toast({
        title: "Password Too Short",
        description: "Password must be at least 6 characters long.",
        variant: "destructive",
      })
      return
    }

    // In a real app, you would call an API to change the password
    toast({
      title: "Password Changed",
      description: "Your password has been updated successfully.",
    })

    // Reset password fields
    setPasswordData({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    })
  }

  if (isLoading || !user) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold">Loading...</h2>
          <p className="text-muted-foreground">Please wait while we load your profile</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10">
      <div className="flex flex-col space-y-8">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold">My Profile</h1>
          <p className="text-muted-foreground">Manage your account settings and preferences</p>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <div className="md:w-1/4">
            <Card>
              <CardContent className="p-6 flex flex-col items-center space-y-4">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={user.image} alt={user.name} />
                  <AvatarFallback>{user.name[0]}</AvatarFallback>
                </Avatar>
                <div className="text-center">
                  <h2 className="text-xl font-bold">{user.name}</h2>
                  <p className="text-sm text-muted-foreground capitalize">{user.role}</p>
                </div>
                <Separator />
                <div className="w-full">
                  <p className="text-sm text-muted-foreground">Member since</p>
                  <p className="font-medium">{new Date().toLocaleDateString()}</p>
                </div>
                <Button variant="outline" className="w-full" onClick={() => router.push("/dashboard")}>
                  View Dashboard
                </Button>
                <Button variant="destructive" className="w-full" onClick={logout}>
                  Log Out
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <Tabs defaultValue="general">
              {/* Add a language tab to the tabs list */}
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="general">{t("profile.general")}</TabsTrigger>
                <TabsTrigger value="security">{t("profile.security")}</TabsTrigger>
                <TabsTrigger value="notifications">{t("profile.notifications")}</TabsTrigger>
                <TabsTrigger value="language">{t("profile.language")}</TabsTrigger>
              </TabsList>

              <TabsContent value="general" className="mt-6 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>General Information</CardTitle>
                    <CardDescription>Update your personal information</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input id="name" value={profileData.name} onChange={handleProfileChange} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" value={profileData.email} onChange={handleProfileChange} />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="role">Role</Label>
                      <Select value={profileData.role} onValueChange={handleRoleChange}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select your role" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="farmer">Farmer</SelectItem>
                          <SelectItem value="consultant">Agricultural Consultant</SelectItem>
                          <SelectItem value="leader">Community Leader</SelectItem>
                          <SelectItem value="agency">Government Agency</SelectItem>
                          <SelectItem value="scientist">Data Scientist</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" value={profileData.phone} onChange={handleProfileChange} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="address">Address</Label>
                      <Input id="address" value={profileData.address} onChange={handleProfileChange} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Input id="bio" value={profileData.bio} onChange={handleProfileChange} />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={saveProfile}>Save Changes</Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="security" className="mt-6 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Change Password</CardTitle>
                    <CardDescription>Update your password</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="currentPassword">Current Password</Label>
                      <Input
                        id="currentPassword"
                        type="password"
                        value={passwordData.currentPassword}
                        onChange={handlePasswordChange}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="newPassword">New Password</Label>
                      <Input
                        id="newPassword"
                        type="password"
                        value={passwordData.newPassword}
                        onChange={handlePasswordChange}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">Confirm New Password</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        value={passwordData.confirmPassword}
                        onChange={handlePasswordChange}
                      />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={changePassword}>Update Password</Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Two-Factor Authentication</CardTitle>
                    <CardDescription>Add an extra layer of security to your account</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Two-Factor Authentication</p>
                        <p className="text-sm text-muted-foreground">Protect your account with 2FA</p>
                      </div>
                      <Button variant="outline">Enable</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="notifications" className="mt-6 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Notification Preferences</CardTitle>
                    <CardDescription>Manage how you receive notifications</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Notification Channels</h3>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Email Notifications</p>
                          <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                        </div>
                        <Switch
                          checked={notificationSettings.email}
                          onCheckedChange={(checked) => handleNotificationChange("email", checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Push Notifications</p>
                          <p className="text-sm text-muted-foreground">Receive notifications on your device</p>
                        </div>
                        <Switch
                          checked={notificationSettings.push}
                          onCheckedChange={(checked) => handleNotificationChange("push", checked)}
                        />
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Notification Types</h3>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Weather Alerts</p>
                          <p className="text-sm text-muted-foreground">Receive alerts about weather conditions</p>
                        </div>
                        <Switch
                          checked={notificationSettings.weatherAlerts}
                          onCheckedChange={(checked) => handleNotificationChange("weatherAlerts", checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Soil Condition Updates</p>
                          <p className="text-sm text-muted-foreground">Get notified about soil moisture and health</p>
                        </div>
                        <Switch
                          checked={notificationSettings.soilConditions}
                          onCheckedChange={(checked) => handleNotificationChange("soilConditions", checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Market Price Updates</p>
                          <p className="text-sm text-muted-foreground">Receive updates on crop market prices</p>
                        </div>
                        <Switch
                          checked={notificationSettings.marketPrices}
                          onCheckedChange={(checked) => handleNotificationChange("marketPrices", checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Community Updates</p>
                          <p className="text-sm text-muted-foreground">Get notified about community activities</p>
                        </div>
                        <Switch
                          checked={notificationSettings.communityUpdates}
                          onCheckedChange={(checked) => handleNotificationChange("communityUpdates", checked)}
                        />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={saveNotifications}>Save Preferences</Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              {/* Add the language tab content after the notifications tab content */}
              <TabsContent value="language" className="mt-6 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>{t("language.select")}</CardTitle>
                    <CardDescription>Choose your preferred language for the application</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <input
                          type="radio"
                          id="language-en"
                          name="language"
                          checked={language === "en"}
                          onChange={() => setLanguage("en")}
                          className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                        />
                        <label
                          htmlFor="language-en"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {t("language.english")}
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input
                          type="radio"
                          id="language-hi"
                          name="language"
                          checked={language === "hi"}
                          onChange={() => setLanguage("hi")}
                          className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                        />
                        <label
                          htmlFor="language-hi"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {t("language.hindi")}
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input
                          type="radio"
                          id="language-ta"
                          name="language"
                          checked={language === "ta"}
                          onChange={() => setLanguage("ta")}
                          className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                        />
                        <label
                          htmlFor="language-ta"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {t("language.tamil")}
                        </label>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <p className="text-sm text-muted-foreground">
                      Language changes will be applied immediately across the application.
                    </p>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
