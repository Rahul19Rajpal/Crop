import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

export default function AboutPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">About AgriPredict</h1>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">
                  A comprehensive agricultural management platform designed to empower farmers and agricultural
                  stakeholders.
                </p>
              </div>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  The Community-Driven Crop Yield Prediction and Optimization System is designed to help local farmers,
                  agricultural consultants, community leaders, and government agencies collaborate on predicting crop
                  yields and optimizing agricultural practices through data-driven approaches.
                </p>
                <p>
                  Our platform collects and processes various agricultural data points including weather patterns, soil
                  conditions, and historical yield information to provide accurate crop yield predictions and
                  optimization recommendations.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative h-[400px] w-full overflow-hidden rounded-xl">
                <Image
                  src="/images/agriculture-field.jpg"
                  alt="About AgriPredict"
                  fill
                  className="object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement
                    target.src = "/placeholder.svg?height=800&width=800"
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Our Mission</h2>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Enhancing agricultural productivity, resource efficiency, and sustainability through data-driven
                insights and community collaboration.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 py-12 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Empower Farmers</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Provide farmers with the tools and insights they need to make informed decisions about their crops and
                  agricultural practices.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Foster Collaboration</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Create a platform where agricultural stakeholders can share knowledge, experiences, and best
                  practices.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Promote Sustainability</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Encourage sustainable farming practices through data-driven recommendations and resource optimization.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Challenges Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Addressing Agricultural Challenges</h2>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Our platform aims to solve key challenges faced by the agricultural community
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Uncertainty in Crop Planning</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Farmers lack reliable tools to predict yields based on changing environmental factors, making it
                  difficult to plan resource allocation effectively.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Inefficient Resource Utilization</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Without data-driven insights, farmers often over or under-utilize critical resources like water,
                  fertilizers, and pesticides.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Knowledge Fragmentation</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Successful agricultural practices developed by experienced farmers remain isolated and are not
                  systematically shared with the broader farming community.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Limited Data Integration</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Agricultural data from various sources (weather stations, soil tests, satellite imagery) exist in
                  isolation rather than being integrated for comprehensive analysis.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Inadequate Risk Management</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Farmers lack effective tools to identify and mitigate potential risks to their crops throughout the
                  growing season.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Policy Disconnection</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Government agricultural policies are often formulated without sufficient data-driven insights from
                  actual farming communities.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
