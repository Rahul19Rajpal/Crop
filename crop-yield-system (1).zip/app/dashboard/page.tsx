"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, LineChart, PieChart, AlertTriangle, Droplets, Trash2, RefreshCw, Search, Plus } from "lucide-react"
import { useAuth } from "@/components/auth-provider"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"
import DataVisualization from "@/components/data-visualization"
import { getWeatherForecast, getPopularCities, type WeatherForecast } from "@/lib/weather-service"
import { getSoilData, type SoilData } from "@/lib/soil-service"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Image from "next/image"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

// Import the API service as default
import api from "@/lib/api-service"
import { useLanguage } from "@/components/language-provider"

// Sample data for the dashboard
const cropData = [
  {
    id: 1,
    name: "Wheat",
    area: 45,
    predictedYield: 6.2,
    lastYield: 5.8,
    status: "Healthy",
    soilMoisture: 68,
    lastWatered: "2 days ago",
  },
  {
    id: 2,
    name: "Corn",
    area: 30,
    predictedYield: 9.5,
    lastYield: 8.7,
    status: "Needs attention",
    soilMoisture: 42,
    lastWatered: "5 days ago",
  },
  {
    id: 3,
    name: "Soybeans",
    area: 25,
    predictedYield: 3.8,
    lastYield: 3.5,
    status: "Healthy",
    soilMoisture: 71,
    lastWatered: "1 day ago",
  },
  {
    id: 4,
    name: "Rice",
    area: 15,
    predictedYield: 7.1,
    lastYield: 6.8,
    status: "Healthy",
    soilMoisture: 85,
    lastWatered: "Today",
  },
]

const recommendations = [
  {
    id: 1,
    title: "Adjust Irrigation Schedule",
    description: "Based on soil moisture readings and weather forecast, reduce irrigation by 15% for the next week.",
    priority: "Medium",
    crop: "Wheat",
  },
  {
    id: 2,
    title: "Fertilizer Application",
    description: "Apply nitrogen-rich fertilizer to corn fields within the next 5 days for optimal growth.",
    priority: "High",
    crop: "Corn",
  },
  {
    id: 3,
    title: "Pest Control Alert",
    description: "Early signs of aphid infestation detected in wheat fields. Consider preventative measures.",
    priority: "High",
    crop: "Wheat",
  },
  {
    id: 4,
    title: "Harvest Planning",
    description: "Optimal harvest window for soybeans predicted to be between 15-20 days from now.",
    priority: "Low",
    crop: "Soybeans",
  },
]

export default function DashboardPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("overview")
  const [weatherForecast, setWeatherForecast] = useState<WeatherForecast[]>([])
  const [userRecommendations, setUserRecommendations] = useState(recommendations)
  const [showNewFieldDialog, setShowNewFieldDialog] = useState(false)
  const [showNewMeasurementDialog, setShowNewMeasurementDialog] = useState(false)
  const [newField, setNewField] = useState({ name: "", area: "", cropType: "" })
  const [newMeasurement, setNewMeasurement] = useState({ type: "", value: "", field: "" })
  const [userFields, setUserFields] = useState(cropData)
  const [userMeasurements, setUserMeasurements] = useState([
    { id: 1, type: "Soil pH Level", value: "6.8", date: "3 days ago", field: "Field 1" },
    { id: 2, type: "Nitrogen Content", value: "42 ppm", date: "1 week ago", field: "Field 2" },
    { id: 3, type: "Phosphorus Level", value: "28 ppm", date: "1 week ago", field: "Field 3" },
  ])
  const [selectedCity, setSelectedCity] = useState("New York")
  const [soilData, setSoilData] = useState<SoilData | null>(null)
  const [selectedLocation, setSelectedLocation] = useState("Field 1")
  const [showDeleteFieldDialog, setShowDeleteFieldDialog] = useState(false)
  const [fieldToDelete, setFieldToDelete] = useState<number | null>(null)
  const [showDeleteMeasurementDialog, setShowDeleteMeasurementDialog] = useState(false)
  const [measurementToDelete, setMeasurementToDelete] = useState<number | null>(null)
  // Add state for custom city input
  const [customCity, setCustomCity] = useState("")

  // Add the useLanguage hook to the component
  const { t } = useLanguage()

  // Update the useEffect to load data from the API
  useEffect(() => {
    // Check if user is stored in localStorage
    const storedUser = localStorage.getItem("user")
    if (storedUser && !isLoading) {
      const user = JSON.parse(storedUser)

      // Load fields from user-specific localStorage
      const storedFields = localStorage.getItem(`userFields_${user.id}`)
      if (storedFields) {
        const fields = JSON.parse(storedFields)
        if (fields.length > 0) {
          setUserFields(fields)
        } else {
          // If no fields, use the default cropData
          setUserFields(cropData)
          // Save default data to user's storage
          localStorage.setItem(`userFields_${user.id}`, JSON.stringify(cropData))
        }
      } else {
        // If no stored fields, use the default cropData
        setUserFields(cropData)
        // Save default data to user's storage
        localStorage.setItem(`userFields_${user.id}`, JSON.stringify(cropData))
      }

      // Load measurements from user-specific localStorage
      const storedMeasurements = localStorage.getItem(`userMeasurements_${user.id}`)
      if (storedMeasurements) {
        const measurements = JSON.parse(storedMeasurements)
        if (measurements.length > 0) {
          setUserMeasurements(measurements)
        } else {
          // If no measurements, use the default measurements
          localStorage.setItem(`userMeasurements_${user.id}`, JSON.stringify(userMeasurements))
        }
      } else {
        // If no stored measurements, save the default ones
        localStorage.setItem(`userMeasurements_${user.id}`, JSON.stringify(userMeasurements))
      }

      // Load recommendations from user-specific localStorage
      const storedRecommendations = localStorage.getItem(`userRecommendations_${user.id}`)
      if (storedRecommendations) {
        const recs = JSON.parse(storedRecommendations)
        if (recs.length > 0) {
          setUserRecommendations(recs)
        } else {
          // If no recommendations, use the default recommendations
          setUserRecommendations(recommendations)
          localStorage.setItem(`userRecommendations_${user.id}`, JSON.stringify(recommendations))
        }
      } else {
        // If no stored recommendations, use the default recommendations
        setUserRecommendations(recommendations)
        localStorage.setItem(`userRecommendations_${user.id}`, JSON.stringify(recommendations))
      }

      // Try to load from API (this will be a fallback)
      api
        .getFields(user.id)
        .then((fields) => {
          if (fields.length > 0) {
            setUserFields(fields)
            localStorage.setItem(`userFields_${user.id}`, JSON.stringify(fields))
          }
        })
        .catch((error) => console.error("Failed to load fields:", error))

      api
        .getMeasurements(user.id)
        .then((measurements) => {
          if (measurements.length > 0) {
            setUserMeasurements(measurements)
            localStorage.setItem(`userMeasurements_${user.id}`, JSON.stringify(measurements))
          }
        })
        .catch((error) => console.error("Failed to load measurements:", error))

      api
        .getRecommendations(user.id)
        .then((recommendations) => {
          if (recommendations.length > 0) {
            setUserRecommendations(recommendations)
            localStorage.setItem(`userRecommendations_${user.id}`, JSON.stringify(recommendations))
          }
        })
        .catch((error) => console.error("Failed to load recommendations:", error))
    }

    // Load weather data
    const loadWeatherData = async () => {
      try {
        const forecast = await getWeatherForecast(selectedCity)
        setWeatherForecast(forecast)
      } catch (error) {
        console.error("Failed to load weather data:", error)
        // Fallback to default data if API fails
        setWeatherForecast([
          {
            day: "Today",
            temp: 28,
            condition: "Sunny",
            icon: "https://openweathermap.org/img/wn/01d@2x.png",
            precipitation: 0,
          },
          {
            day: "Tomorrow",
            temp: 26,
            condition: "Partly Cloudy",
            icon: "https://openweathermap.org/img/wn/02d@2x.png",
            precipitation: 10,
          },
          {
            day: "Wednesday",
            temp: 24,
            condition: "Cloudy",
            icon: "https://openweathermap.org/img/wn/03d@2x.png",
            precipitation: 30,
          },
          {
            day: "Thursday",
            temp: 22,
            condition: "Light Rain",
            icon: "https://openweathermap.org/img/wn/10d@2x.png",
            precipitation: 60,
          },
          {
            day: "Friday",
            temp: 25,
            condition: "Sunny",
            icon: "https://openweathermap.org/img/wn/01d@2x.png",
            precipitation: 0,
          },
        ])
      }
    }

    // Load soil data
    const loadSoilData = async () => {
      try {
        const data = await getSoilData(selectedLocation)
        setSoilData(data)
      } catch (error) {
        console.error("Failed to load soil data:", error)
      }
    }

    // Load saved data from localStorage
    const loadSavedData = () => {
      if (typeof window !== "undefined") {
        // Load selected city
        const savedCity = localStorage.getItem("selectedCity")
        if (savedCity) {
          setSelectedCity(savedCity)
        }

        // Load selected location
        const savedLocation = localStorage.getItem("selectedLocation")
        if (savedLocation) {
          setSelectedLocation(savedLocation)
        }
      }
    }

    // Simulate data loading
    const timer = setTimeout(() => {
      setLoading(false)
      loadWeatherData()
      loadSoilData()
      loadSavedData()
    }, 1000)

    // If not logged in and not loading, redirect to login
    if (!isLoading && !user) {
      toast({
        title: "Authentication required",
        description: "Please log in to access the dashboard.",
        variant: "destructive",
      })
      router.push("/login")
    }

    return () => clearTimeout(timer)
  }, [user, isLoading, router, toast, selectedCity, selectedLocation])

  // Update the handleDismissRecommendation function to use user-specific storage
  const handleDismissRecommendation = async (id: number) => {
    try {
      // First try the API
      let success = false
      try {
        success = await api.dismissRecommendation(id)
      } catch (error) {
        console.error("API call failed, using local storage instead:", error)
      }

      // Whether API succeeded or not, update local state and storage
      const updatedRecommendations = userRecommendations.filter((rec) => rec.id !== id)
      setUserRecommendations(updatedRecommendations)

      // Save to user-specific storage
      if (user) {
        localStorage.setItem(`userRecommendations_${user.id}`, JSON.stringify(updatedRecommendations))
      }

      toast({
        title: "Recommendation Dismissed",
        description: "The recommendation has been removed from your list.",
      })

      return true
    } catch (error) {
      console.error("Failed to dismiss recommendation:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }

  // Update the handleImplementRecommendation function to use user-specific storage
  const handleImplementRecommendation = async (id: number) => {
    try {
      const recommendation = userRecommendations.find((rec) => rec.id === id)

      // First try the API
      let success = false
      try {
        success = await api.implementRecommendation(id)
      } catch (error) {
        console.error("API call failed, using local storage instead:", error)
      }

      // Whether API succeeded or not, update local state and storage
      const updatedRecommendations = userRecommendations.filter((rec) => rec.id !== id)
      setUserRecommendations(updatedRecommendations)

      // Save to user-specific storage
      if (user) {
        localStorage.setItem(`userRecommendations_${user.id}`, JSON.stringify(updatedRecommendations))
      }

      toast({
        title: "Recommendation Implemented",
        description: `You've implemented: ${recommendation?.title}`,
      })

      return true
    } catch (error) {
      console.error("Failed to implement recommendation:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }

  // Handle field and measurement dialogs
  // Update handleAddNewField to use user-specific storage
  const handleAddNewField = () => {
    if (!newField.name || !newField.area || !newField.cropType) {
      toast({
        title: "Missing Information",
        description: "Please fill in all field details.",
        variant: "destructive",
      })
      return
    }

    const newFieldObj = {
      id: Date.now(),
      name: newField.cropType,
      area: Number.parseInt(newField.area),
      predictedYield: Math.round((Math.random() * 5 + 3) * 10) / 10,
      lastYield: Math.round((Math.random() * 4 + 3) * 10) / 10,
      status: Math.random() > 0.7 ? "Needs attention" : "Healthy",
      soilMoisture: Math.round(Math.random() * 40 + 50),
      lastWatered: "Not yet watered",
    }

    const updatedFields = [...userFields, newFieldObj]
    setUserFields(updatedFields)

    // Save to user-specific storage
    if (user) {
      localStorage.setItem(`userFields_${user.id}`, JSON.stringify(updatedFields))
    }

    setNewField({ name: "", area: "", cropType: "" })
    setShowNewFieldDialog(false)

    toast({
      title: "Field Added",
      description: `${newField.name} has been added to your fields.`,
    })
  }

  // Update handleDeleteField to use user-specific storage
  const handleDeleteField = () => {
    if (fieldToDelete === null) return

    const updatedFields = userFields.filter((field) => field.id !== fieldToDelete)
    setUserFields(updatedFields)

    // Save to user-specific storage
    if (user) {
      localStorage.setItem(`userFields_${user.id}`, JSON.stringify(updatedFields))
    }

    setFieldToDelete(null)
    setShowDeleteFieldDialog(false)

    toast({
      title: "Field Deleted",
      description: "The field has been removed from your account.",
    })
  }

  // Update handleAddNewMeasurement to use user-specific storage
  const handleAddNewMeasurement = () => {
    if (!newMeasurement.type || !newMeasurement.value || !newMeasurement.field) {
      toast({
        title: "Missing Information",
        description: "Please fill in all measurement details.",
        variant: "destructive",
      })
      return
    }

    const newMeasurementObj = {
      id: Date.now(),
      type: newMeasurement.type,
      value: newMeasurement.value,
      date: "Just now",
      field: newMeasurement.field,
    }

    const updatedMeasurements = [...userMeasurements, newMeasurementObj]
    setUserMeasurements(updatedMeasurements)

    // Save to user-specific storage
    if (user) {
      localStorage.setItem(`userMeasurements_${user.id}`, JSON.stringify(updatedMeasurements))
    }

    setNewMeasurement({ type: "", value: "", field: "" })
    setShowNewMeasurementDialog(false)

    toast({
      title: "Measurement Recorded",
      description: `${newMeasurement.type} has been recorded for ${newMeasurement.field}.`,
    })
  }

  // Update handleDeleteMeasurement to use user-specific storage
  const handleDeleteMeasurement = () => {
    if (measurementToDelete === null) return

    const updatedMeasurements = userMeasurements.filter((measurement) => measurement.id !== measurementToDelete)
    setUserMeasurements(updatedMeasurements)

    // Save to user-specific storage
    if (user) {
      localStorage.setItem(`userMeasurements_${user.id}`, JSON.stringify(updatedMeasurements))
    }

    setMeasurementToDelete(null)
    setShowDeleteMeasurementDialog(false)

    toast({
      title: "Measurement Deleted",
      description: "The measurement has been removed from your records.",
    })
  }

  const handleCityChange = (city: string) => {
    setSelectedCity(city)
    localStorage.setItem("selectedCity", city)

    // Reload weather data
    getWeatherForecast(city)
      .then((forecast) => {
        setWeatherForecast(forecast)
        toast({
          title: "Weather Updated",
          description: `Weather forecast updated for ${city}.`,
        })
      })
      .catch((error) => {
        console.error("Failed to load weather data:", error)
        toast({
          title: "Weather Update Failed",
          description: "Could not update weather forecast. Please try again.",
          variant: "destructive",
        })
      })
  }

  const handleLocationChange = (location: string) => {
    setSelectedLocation(location)
    localStorage.setItem("selectedLocation", location)

    // Reload soil data
    getSoilData(location)
      .then((data) => {
        setSoilData(data)
        toast({
          title: "Soil Data Updated",
          description: `Soil data updated for ${location}.`,
        })
      })
      .catch((error) => {
        console.error("Failed to load soil data:", error)
        toast({
          title: "Soil Data Update Failed",
          description: "Could not update soil data. Please try again.",
          variant: "destructive",
        })
      })
  }

  if (isLoading || !user) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold">Loading...</h2>
          <p className="text-muted-foreground">Please wait while we prepare your dashboard</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col">
      <section className="w-full py-12 bg-gradient-to-b from-green-50 to-white dark:from-green-950/30 dark:to-background">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col space-y-4">
            <div className="space-y-2">
              {/* Update the welcome message to use translations */}
              <h1 className="text-3xl font-bold tracking-tighter">
                {t("dashboard.welcome")}, {user.name}
              </h1>
              <p className="text-muted-foreground">
                Your agricultural dashboard -{" "}
                {new Date().toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
            </div>
            <Tabs defaultValue="overview" className="w-full" value={activeTab} onValueChange={setActiveTab}>
              {/* Update the tabs to use translations */}
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">{t("dashboard.overview")}</TabsTrigger>
                <TabsTrigger value="predictions">{t("dashboard.predictions")}</TabsTrigger>
                <TabsTrigger value="recommendations">{t("dashboard.recommendations")}</TabsTrigger>
                <TabsTrigger value="data">{t("dashboard.data")}</TabsTrigger>
              </TabsList>
              <TabsContent value="overview" className="mt-6 space-y-6">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  <Card className="border-green-100 dark:border-green-900/50">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      {/* Update the card titles to use translations */}
                      <CardTitle className="text-sm font-medium">{t("dashboard.totalFields")}</CardTitle>
                      <div className="h-4 w-4 text-green-600">
                        <BarChart className="h-4 w-4" />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{userFields.length}</div>
                      <p className="text-xs text-muted-foreground">
                        +{userFields.length - cropData.length} from last season
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="border-green-100 dark:border-green-900/50">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      {/* Update the card titles to use translations */}
                      <CardTitle className="text-sm font-medium">{t("dashboard.activeCrops")}</CardTitle>
                      <div className="h-4 w-4 text-green-600">
                        <PieChart className="h-4 w-4" />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">4</div>
                      <p className="text-xs text-muted-foreground">Wheat, Corn, Soybeans, Rice</p>
                    </CardContent>
                  </Card>
                  <Card className="border-green-100 dark:border-green-900/50">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      {/* Update the card titles to use translations */}
                      <CardTitle className="text-sm font-medium">{t("dashboard.predictedYield")}</CardTitle>
                      <div className="h-4 w-4 text-green-600">
                        <LineChart className="h-4 w-4" />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">+12.5%</div>
                      <p className="text-xs text-muted-foreground">Compared to last season</p>
                    </CardContent>
                  </Card>
                  <Card className="border-green-100 dark:border-green-900/50">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      {/* Update the card titles to use translations */}
                      <CardTitle className="text-sm font-medium">{t("dashboard.weatherForecast")}</CardTitle>
                      <div className="h-4 w-4 text-green-600">
                        <BarChart className="h-4 w-4" />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {weatherForecast.length > 0 ? weatherForecast[0].condition : "Loading..."}
                      </div>
                      <p className="text-xs text-muted-foreground">Next 7 days outlook</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Weather Forecast */}
                <Card className="border-green-100 dark:border-green-900/50">
                  <CardHeader className="flex justify-between items-center">
                    <div>
                      <CardTitle>Weather Forecast</CardTitle>
                      <CardDescription>Weather predictions for your region</CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-2">
                        <Input
                          placeholder="Enter city"
                          value={customCity}
                          onChange={(e) => setCustomCity(e.target.value)}
                          className="w-[180px]"
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => {
                            if (customCity.trim()) {
                              handleCityChange(customCity.trim())
                            }
                          }}
                          title="Search city"
                        >
                          <Search className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="mx-2">or</div>
                      <Select value={selectedCity} onValueChange={handleCityChange}>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Select city" />
                        </SelectTrigger>
                        <SelectContent>
                          {getPopularCities().map((city) => (
                            <SelectItem key={city} value={city}>
                              {city}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleCityChange(selectedCity)}
                        title="Refresh weather data"
                      >
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-5 gap-4">
                      {weatherForecast.map((day, index) => (
                        <div
                          key={index}
                          className="flex flex-col items-center justify-center p-2 rounded-lg bg-muted/50"
                        >
                          <span className="font-medium">{day.day}</span>
                          {day.icon ? (
                            <img
                              src={day.icon || "/placeholder.svg"}
                              alt={day.condition}
                              style={{ width: "50px", height: "50px" }}
                              className="my-2"
                              onError={(e) => {
                                e.currentTarget.src = "https://openweathermap.org/img/wn/01d@2x.png"
                              }}
                            />
                          ) : (
                            <div className="h-[50px] w-[50px] my-2 flex items-center justify-center bg-muted rounded-full">
                              {day.condition === "Sunny" && "☀️"}
                              {day.condition === "Partly Cloudy" && "⛅"}
                              {day.condition === "Cloudy" && "☁️"}
                              {day.condition === "Light Rain" && "🌧️"}
                              {day.condition === "Heavy Rain" && "⛈️"}
                              {!["Sunny", "Partly Cloudy", "Cloudy", "Light Rain", "Heavy Rain"].includes(
                                day.condition,
                              ) && "🌤️"}
                            </div>
                          )}

                          <span className="font-bold">{day.temp}°C</span>
                          <span className="text-xs text-muted-foreground">{day.condition}</span>
                          <span className="text-xs text-muted-foreground">{day.precipitation}% rain</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Data Visualization */}
                <DataVisualization userFields={userFields} />
                {/* Crop Status */}
                <Card className="border-green-100 dark:border-green-900/50">
                  <CardHeader>
                    <CardTitle>Crop Status</CardTitle>
                    <CardDescription>Current status of your active crops</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {userFields.map((crop) => (
                        <div key={crop.id} className="grid grid-cols-1 md:grid-cols-6 gap-4 items-center border-b pb-4">
                          <div className="font-medium">{crop.name}</div>
                          <div className="text-sm text-muted-foreground">{crop.area} acres</div>
                          <div className="flex items-center">
                            <Droplets className="h-4 w-4 mr-1 text-blue-500" />
                            <div className="w-full">
                              <div className="flex justify-between text-xs mb-1">
                                <span>Soil Moisture</span>
                                <span>{crop.soilMoisture}%</span>
                              </div>
                              <Progress value={crop.soilMoisture} className="h-2" />
                            </div>
                          </div>
                          <div className="text-sm">
                            Last watered: <span className="text-muted-foreground">{crop.lastWatered}</span>
                          </div>
                          <div className="text-sm">
                            Predicted yield: <span className="font-medium">{crop.predictedYield} tons/acre</span>
                          </div>
                          <div className="flex items-center justify-between">
                            {crop.status === "Healthy" ? (
                              <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800 dark:bg-green-900/30 dark:text-green-300">
                                Healthy
                              </span>
                            ) : (
                              <span className="inline-flex items-center rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs font-medium text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                Needs attention
                              </span>
                            )}
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7 text-red-500 hover:text-red-700 hover:bg-red-100"
                              onClick={() => {
                                setFieldToDelete(crop.id)
                                setShowDeleteFieldDialog(true)
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card className="col-span-2 border-green-100 dark:border-green-900/50">
                    <CardHeader>
                      <CardTitle>Recent Recommendations</CardTitle>
                      <CardDescription>Latest optimization suggestions for your crops</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {userRecommendations.slice(0, 3).map((rec) => (
                          <div key={rec.id} className="border-b pb-4">
                            <div className="flex items-center justify-between">
                              <h3 className="font-medium">{rec.title}</h3>
                              <span
                                className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                                  rec.priority === "High"
                                    ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
                                    : rec.priority === "Medium"
                                      ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300"
                                      : "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300"
                                }`}
                              >
                                {rec.priority} Priority
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">{rec.description}</p>
                            <p className="text-xs text-muted-foreground mt-2">Crop: {rec.crop}</p>
                          </div>
                        ))}
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full"
                          onClick={() => setActiveTab("recommendations")}
                        >
                          View All Recommendations
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="border-green-100 dark:border-green-900/50">
                    <CardHeader>
                      <CardTitle>Community Insights</CardTitle>
                      <CardDescription>Recent knowledge shared by your community</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="border-b pb-4">
                          <h3 className="font-medium">New Drought-Resistant Wheat Variety</h3>
                          <p className="text-sm text-muted-foreground">Shared by Agricultural Consultant John D.</p>
                        </div>
                        <div className="border-b pb-4">
                          <h3 className="font-medium">Organic Pest Control Methods</h3>
                          <p className="text-sm text-muted-foreground">Discussion thread with 15 contributions</p>
                        </div>
                        <div>
                          <h3 className="font-medium">Local Farmers Market Schedule</h3>
                          <p className="text-sm text-muted-foreground">Posted by Community Leader Sarah M.</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="predictions" className="mt-6 space-y-6">
                <Card className="border-green-100 dark:border-green-900/50">
                  <CardHeader>
                    <CardTitle>Crop Yield Predictions</CardTitle>
                    <CardDescription>Forecasted yields based on current conditions and historical data</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="relative h-[400px] w-full">
                      <Image
                        src="https://images.unsplash.com/photo-1605000797499-95a51c5269ae?q=80&w=2071&auto=format&fit=crop"
                        alt="Yield Predictions Chart"
                        fill
                        className="object-cover rounded-md"
                      />
                    </div>
                    <div className="mt-6 space-y-4">
                      <h3 className="text-lg font-medium">Prediction Analysis</h3>
                      <p className="text-muted-foreground">
                        Based on current weather patterns, soil conditions, and historical data, our AI model predicts
                        the following yields for your crops:
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        {userFields.map((crop) => (
                          <div key={crop.id} className="p-4 bg-muted/50 rounded-lg">
                            <div className="flex justify-between items-center">
                              <h4 className="font-medium">{crop.name}</h4>
                              <span className="text-sm font-bold">{crop.predictedYield} tons/acre</span>
                            </div>
                            <div className="mt-2">
                              <div className="flex justify-between text-xs mb-1">
                                <span>Confidence Level</span>
                                <span>{Math.round(Math.random() * 20 + 75)}%</span>
                              </div>
                              <Progress value={Math.round(Math.random() * 20 + 75)} className="h-2" />
                            </div>
                            <p className="text-xs text-muted-foreground mt-2">
                              {crop.predictedYield > crop.lastYield
                                ? `+${(((crop.predictedYield - crop.lastYield) / crop.lastYield) * 100).toFixed(1)}% increase from last season`
                                : `${(((crop.lastYield - crop.predictedYield) / crop.lastYield) * 100).toFixed(1)}% decrease from last season`}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="recommendations" className="mt-6 space-y-6">
                <Card className="border-green-100 dark:border-green-900/50">
                  <CardHeader>
                    <CardTitle>Optimization Recommendations</CardTitle>
                    <CardDescription>Suggested actions to improve crop yields and resource efficiency</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {userRecommendations.map((rec) => (
                        <div key={rec.id} className="border-b pb-6">
                          <div className="flex items-center justify-between">
                            <h3 className="text-lg font-medium">{rec.title}</h3>
                            <span
                              className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                                rec.priority === "High"
                                  ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
                                  : rec.priority === "Medium"
                                    ? "bg-yellow-100 text-yellow-800 dark:bg"
                                    : "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300"
                              }`}
                            >
                              {rec.priority} Priority
                            </span>
                          </div>
                          <p className="text-muted-foreground mt-2">{rec.description}</p>
                          <div className="flex justify-between items-center mt-4">
                            <p className="text-sm text-muted-foreground">
                              Crop: <span className="font-medium">{rec.crop}</span>
                            </p>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" onClick={() => handleDismissRecommendation(rec.id)}>
                                Dismiss
                              </Button>
                              <Button
                                size="sm"
                                className="bg-green-600 hover:bg-green-700 text-white"
                                onClick={() => handleImplementRecommendation(rec.id)}
                              >
                                Implement
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                      {userRecommendations.length === 0 && (
                        <div className="text-center py-8">
                          <p className="text-muted-foreground">No active recommendations at this time.</p>
                          <Button
                            variant="outline"
                            className="mt-4"
                            onClick={() => {
                              setUserRecommendations(recommendations)
                              localStorage.setItem("userRecommendations", JSON.stringify(recommendations))
                              toast({
                                title: "Recommendations Reset",
                                description: "Default recommendations have been restored.",
                              })
                            }}
                          >
                            Reset Recommendations
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="data" className="mt-6 space-y-6">
                <Card className="border-green-100 dark:border-green-900/50">
                  <CardHeader>
                    <CardTitle>My Agricultural Data</CardTitle>
                    <CardDescription>View and manage your field data, crop history, and measurements</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <DataVisualization userFields={userFields} />

                      {/* Soil Data Section */}
                      <div className="mt-6">
                        <div className="flex justify-between items-center mb-4">
                          <h3 className="text-lg font-medium">Soil Analysis</h3>
                          <div className="flex items-center gap-2">
                            <Select value={selectedLocation} onValueChange={handleLocationChange}>
                              <SelectTrigger className="w-[180px]">
                                <SelectValue placeholder="Select location" />
                              </SelectTrigger>
                              <SelectContent>
                                {userFields.map((field) => (
                                  <SelectItem key={field.id} value={field.name}>
                                    {field.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => handleLocationChange(selectedLocation)}
                              title="Refresh soil data"
                            >
                              <RefreshCw className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        {soilData ? (
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="p-4 bg-muted/50 rounded-lg">
                              <div className="flex justify-between items-center">
                                <h4 className="font-medium">Soil Moisture</h4>
                                <span className="text-sm font-bold">{soilData.moisture}%</span>
                              </div>
                              <Progress value={soilData.moisture} className="h-2 mt-2" />
                            </div>
                            <div className="p-4 bg-muted/50 rounded-lg">
                              <div className="flex justify-between items-center">
                                <h4 className="font-medium">Soil pH</h4>
                                <span className="text-sm font-bold">{soilData.ph}</span>
                              </div>
                              <Progress value={((soilData.ph - 5.5) / 3) * 100} className="h-2 mt-2" />
                            </div>
                            <div className="p-4 bg-muted/50 rounded-lg">
                              <div className="flex justify-between items-center">
                                <h4 className="font-medium">Organic Matter</h4>
                                <span className="text-sm font-bold">{soilData.organicMatter}%</span>
                              </div>
                              <Progress value={soilData.organicMatter * 10} className="h-2 mt-2" />
                            </div>
                          </div>
                        ) : (
                          <div className="text-center py-8">
                            <p className="text-muted-foreground">Select a location to view soil data.</p>
                          </div>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                        <div className="space-y-4">
                          <h3 className="font-medium text-lg">Field Data</h3>
                          <div className="space-y-2">
                            {userFields.map((crop) => (
                              <div
                                key={crop.id}
                                className="flex justify-between items-center p-3 bg-muted/50 rounded-md"
                              >
                                <span className="font-medium">{crop.name}</span>
                                <div className="flex items-center gap-2">
                                  <span>{crop.area} acres</span>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-7 w-7 text-red-500 hover:text-red-700 hover:bg-red-100"
                                    onClick={() => {
                                      setFieldToDelete(crop.id)
                                      setShowDeleteFieldDialog(true)
                                    }}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                          <Button
                            className="w-full bg-green-600 hover:bg-green-700 text-white"
                            onClick={() => setShowNewFieldDialog(true)}
                          >
                            <Plus className="h-4 w-4 mr-2" />
                            Add New Field
                          </Button>
                        </div>
                        <div className="space-y-4">
                          <h3 className="font-medium text-lg">Recent Measurements</h3>
                          <div className="space-y-2">
                            {userMeasurements.map((measurement) => (
                              <div key={measurement.id} className="p-3 bg-muted/50 rounded-md">
                                <div className="flex justify-between">
                                  <span>{measurement.type}</span>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium">{measurement.value}</span>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-7 w-7 text-red-500 hover:text-red-700 hover:bg-red-100"
                                      onClick={() => {
                                        setMeasurementToDelete(measurement.id)
                                        setShowDeleteMeasurementDialog(true)
                                      }}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </div>
                                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                                  <span>Measured {measurement.date}</span>
                                  <span>{measurement.field}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                          <Button
                            className="w-full bg-green-600 hover:bg-green-700 text-white"
                            onClick={() => setShowNewMeasurementDialog(true)}
                          >
                            <Plus className="h-4 w-4 mr-2" />
                            Record New Measurement
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>

      {/* Add New Field Dialog */}
      <Dialog open={showNewFieldDialog} onOpenChange={setShowNewFieldDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add New Field</DialogTitle>
            <DialogDescription>Enter the details of your new agricultural field.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="field-name" className="text-right">
                Field Name
              </Label>
              <Input
                id="field-name"
                value={newField.name}
                onChange={(e) => setNewField({ ...newField, name: e.target.value })}
                className="col-span-3"
                placeholder="e.g., North Field"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="field-area" className="text-right">
                Area (acres)
              </Label>
              <Input
                id="field-area"
                type="number"
                value={newField.area}
                onChange={(e) => setNewField({ ...newField, area: e.target.value })}
                className="col-span-3"
                placeholder="e.g., 25"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="crop-type" className="text-right">
                Crop Type
              </Label>
              <Input
                id="crop-type"
                value={newField.cropType}
                onChange={(e) => setNewField({ ...newField, cropType: e.target.value })}
                className="col-span-3"
                placeholder="e.g., Wheat"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewFieldDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddNewField}>Add Field</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Field Dialog */}
      <Dialog open={showDeleteFieldDialog} onOpenChange={setShowDeleteFieldDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Delete Field</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this field? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteFieldDialog(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteField}>
              Delete Field
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add New Measurement Dialog */}
      <Dialog open={showNewMeasurementDialog} onOpenChange={setShowNewMeasurementDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Record New Measurement</DialogTitle>
            <DialogDescription>Enter the details of your new agricultural measurement.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="measurement-type" className="text-right">
                Measurement
              </Label>
              <Input
                id="measurement-type"
                value={newMeasurement.type}
                onChange={(e) => setNewMeasurement({ ...newMeasurement, type: e.target.value })}
                className="col-span-3"
                placeholder="e.g., Soil pH Level"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="measurement-value" className="text-right">
                Value
              </Label>
              <Input
                id="measurement-value"
                value={newMeasurement.value}
                onChange={(e) => setNewMeasurement({ ...newMeasurement, value: e.target.value })}
                className="col-span-3"
                placeholder="e.g., 6.5"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="measurement-field" className="text-right">
                Field
              </Label>
              <Select
                value={newMeasurement.field}
                onChange={(value) => setNewMeasurement({ ...newMeasurement, field: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select field" />
                </SelectTrigger>
                <SelectContent>
                  {userFields.map((field) => (
                    <SelectItem key={field.id} value={field.name}>
                      {field.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewMeasurementDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddNewMeasurement}>Record Measurement</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Measurement Dialog */}
      <Dialog open={showDeleteMeasurementDialog} onOpenChange={setShowDeleteMeasurementDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Delete Measurement</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this measurement? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteMeasurementDialog(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteMeasurement}>
              Delete Measurement
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
