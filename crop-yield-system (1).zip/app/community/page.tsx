"use client"

import { useState, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MessageSquare, ThumbsUp, Users, Search } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

// Sample data
const initialDiscussions = [
  {
    id: 1,
    title: "Optimal Irrigation Techniques for Drought Conditions",
    author: {
      name: "John Doe",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JD",
    },
    timeAgo: "2 days ago",
    content:
      "With the recent drought conditions in our region, I'm looking for advice on optimizing irrigation to conserve water while maintaining crop health. Has anyone implemented drip irrigation or other water-saving techniques?",
    likes: 24,
    replies: 18,
    liked: false,
  },
  {
    id: 2,
    title: "Early Detection of Wheat Rust: Signs and Prevention",
    author: {
      name: "Sarah Miller",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SM",
    },
    timeAgo: "5 days ago",
    content:
      "I've noticed some unusual discoloration on my wheat crops and I'm concerned it might be the early stages of wheat rust. Can anyone share their experience with early detection and effective prevention methods?",
    likes: 32,
    replies: 27,
    liked: false,
  },
  {
    id: 3,
    title: "Soil Health Improvement Strategies",
    author: {
      name: "Robert Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "RJ",
    },
    timeAgo: "1 week ago",
    content:
      "I'm looking to improve the overall health of my soil for the next growing season. What cover crops, rotation strategies, or amendments have worked best for others in our region?",
    likes: 45,
    replies: 36,
    liked: false,
  },
]

const initialKnowledgeBase = [
  {
    id: 1,
    title: "Sustainable Farming Practices",
    author: "Agricultural Experts",
    content:
      "A comprehensive guide to sustainable farming practices including crop rotation, cover crops, integrated pest management, and conservation tillage.",
  },
  {
    id: 2,
    title: "Water Conservation Techniques",
    author: "Irrigation Specialists",
    content:
      "Learn about efficient irrigation systems, soil moisture monitoring, and scheduling strategies to minimize water usage while maximizing crop yields.",
  },
  {
    id: 3,
    title: "Pest and Disease Identification",
    author: "Community-Verified Resource",
    content:
      "Visual guide to common crop pests and diseases, with early detection tips and organic management strategies for different crop types.",
  },
]

const initialExperts = [
  {
    id: 1,
    name: "Dr. Emily Rodriguez",
    role: "Soil Science Specialist",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "DR",
    bio: "Expert in soil health, nutrient management, and sustainable soil practices with 15 years of experience in agricultural research.",
  },
  {
    id: 2,
    name: "Michael Peterson",
    role: "Crop Disease Specialist",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "MP",
    bio: "Specializes in identifying and managing crop diseases, with particular expertise in wheat, corn, and soybean pathogens.",
  },
  {
    id: 3,
    name: "Lisa Wong",
    role: "Agricultural Technology Advisor",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "LW",
    bio: "Helps farmers integrate modern technology into their operations, including sensors, drones, and precision agriculture tools.",
  },
]

const initialGroups = [
  {
    id: 1,
    name: "Sustainable Farming Collective",
    members: 243,
    description:
      "A group dedicated to sharing and implementing sustainable farming practices that reduce environmental impact.",
    joined: false,
  },
  {
    id: 2,
    name: "Regional Weather Watch",
    members: 187,
    description:
      "Farmers tracking and discussing local weather patterns and their impact on agricultural planning and operations.",
    joined: false,
  },
  {
    id: 3,
    name: "New Farmers Network",
    members: 156,
    description:
      "Support group for beginning farmers to share experiences, ask questions, and receive guidance from more experienced members.",
    joined: false,
  },
]

export default function CommunityPage() {
  const { user } = useAuth()
  const { toast } = useToast()

  // State for discussions
  const [discussions, setDiscussions] = useState(initialDiscussions)
  const [showNewDiscussionDialog, setShowNewDiscussionDialog] = useState(false)
  const [newDiscussion, setNewDiscussion] = useState({ title: "", content: "" })
  const [searchDiscussions, setSearchDiscussions] = useState("")

  // State for knowledge base
  const [knowledgeBase, setKnowledgeBase] = useState(initialKnowledgeBase)
  const [showNewKnowledgeDialog, setShowNewKnowledgeDialog] = useState(false)
  const [newKnowledge, setNewKnowledge] = useState({ title: "", author: "", content: "" })
  const [searchKnowledge, setSearchKnowledge] = useState("")

  // State for experts
  const [experts, setExperts] = useState(initialExperts)
  const [showContactExpertDialog, setShowContactExpertDialog] = useState(false)
  const [selectedExpert, setSelectedExpert] = useState<any>(null)
  const [expertMessage, setExpertMessage] = useState("")

  // State for groups
  const [groups, setGroups] = useState(initialGroups)
  const [showNewGroupDialog, setShowNewGroupDialog] = useState(false)
  const [newGroup, setNewGroup] = useState({ name: "", description: "" })

  // Load saved data from localStorage
  useEffect(() => {
    const loadSavedData = () => {
      if (typeof window !== "undefined") {
        // Load discussions
        const savedDiscussions = localStorage.getItem("communityDiscussions")
        if (savedDiscussions) {
          setDiscussions(JSON.parse(savedDiscussions))
        }

        // Load knowledge base
        const savedKnowledge = localStorage.getItem("communityKnowledge")
        if (savedKnowledge) {
          setKnowledgeBase(JSON.parse(savedKnowledge))
        }

        // Load groups
        const savedGroups = localStorage.getItem("communityGroups")
        if (savedGroups) {
          setGroups(JSON.parse(savedGroups))
        }
      }
    }

    loadSavedData()
  }, [])

  // Handle discussion actions
  const handleLikeDiscussion = (id: number) => {
    const updatedDiscussions = discussions.map((discussion) => {
      if (discussion.id === id) {
        return {
          ...discussion,
          likes: discussion.liked ? discussion.likes - 1 : discussion.likes + 1,
          liked: !discussion.liked,
        }
      }
      return discussion
    })

    setDiscussions(updatedDiscussions)
    localStorage.setItem("communityDiscussions", JSON.stringify(updatedDiscussions))
  }

  const handleAddDiscussion = () => {
    if (!newDiscussion.title || !newDiscussion.content) {
      toast({
        title: "Missing Information",
        description: "Please provide both a title and content for your discussion.",
        variant: "destructive",
      })
      return
    }

    const newDiscussionObj = {
      id: Date.now(),
      title: newDiscussion.title,
      author: {
        name: user?.name || "Anonymous User",
        avatar: user?.image || "/placeholder.svg?height=40&width=40",
        initials: user?.name?.[0] || "AU",
      },
      timeAgo: "Just now",
      content: newDiscussion.content,
      likes: 0,
      replies: 0,
      liked: false,
    }

    const updatedDiscussions = [newDiscussionObj, ...discussions]
    setDiscussions(updatedDiscussions)
    localStorage.setItem("communityDiscussions", JSON.stringify(updatedDiscussions))

    setNewDiscussion({ title: "", content: "" })
    setShowNewDiscussionDialog(false)

    toast({
      title: "Discussion Created",
      description: "Your discussion has been posted to the community.",
    })
  }

  // Handle knowledge base actions
  const handleAddKnowledge = () => {
    if (!newKnowledge.title || !newKnowledge.content) {
      toast({
        title: "Missing Information",
        description: "Please provide both a title and content for your knowledge article.",
        variant: "destructive",
      })
      return
    }

    const newKnowledgeObj = {
      id: Date.now(),
      title: newKnowledge.title,
      author: newKnowledge.author || user?.name || "Anonymous Contributor",
      content: newKnowledge.content,
    }

    const updatedKnowledge = [newKnowledgeObj, ...knowledgeBase]
    setKnowledgeBase(updatedKnowledge)
    localStorage.setItem("communityKnowledge", JSON.stringify(updatedKnowledge))

    setNewKnowledge({ title: "", author: "", content: "" })
    setShowNewKnowledgeDialog(false)

    toast({
      title: "Knowledge Added",
      description: "Your contribution has been added to the knowledge base.",
    })
  }

  // Handle expert contact
  const handleContactExpert = () => {
    if (!expertMessage) {
      toast({
        title: "Missing Message",
        description: "Please provide a message for the expert.",
        variant: "destructive",
      })
      return
    }

    toast({
      title: "Message Sent",
      description: `Your message has been sent to ${selectedExpert.name}.`,
    })

    setExpertMessage("")
    setShowContactExpertDialog(false)
  }

  // Handle group actions
  const handleJoinGroup = (id: number) => {
    const updatedGroups = groups.map((group) => {
      if (group.id === id) {
        return {
          ...group,
          members: group.joined ? group.members - 1 : group.members + 1,
          joined: !group.joined,
        }
      }
      return group
    })

    setGroups(updatedGroups)
    localStorage.setItem("communityGroups", JSON.stringify(updatedGroups))

    const group = groups.find((g) => g.id === id)
    if (group) {
      toast({
        title: group.joined ? "Left Group" : "Joined Group",
        description: group.joined
          ? `You have left the ${group.name} group.`
          : `You have joined the ${group.name} group.`,
      })
    }
  }

  const handleCreateGroup = () => {
    if (!newGroup.name || !newGroup.description) {
      toast({
        title: "Missing Information",
        description: "Please provide both a name and description for your group.",
        variant: "destructive",
      })
      return
    }

    const newGroupObj = {
      id: Date.now(),
      name: newGroup.name,
      members: 1,
      description: newGroup.description,
      joined: true,
    }

    const updatedGroups = [newGroupObj, ...groups]
    setGroups(updatedGroups)
    localStorage.setItem("communityGroups", JSON.stringify(updatedGroups))

    setNewGroup({ name: "", description: "" })
    setShowNewGroupDialog(false)

    toast({
      title: "Group Created",
      description: `Your group "${newGroup.name}" has been created.`,
    })
  }

  // Filter discussions based on search
  const filteredDiscussions = discussions.filter(
    (discussion) =>
      discussion.title.toLowerCase().includes(searchDiscussions.toLowerCase()) ||
      discussion.content.toLowerCase().includes(searchDiscussions.toLowerCase()),
  )

  // Filter knowledge base based on search
  const filteredKnowledge = knowledgeBase.filter(
    (article) =>
      article.title.toLowerCase().includes(searchKnowledge.toLowerCase()) ||
      article.content.toLowerCase().includes(searchKnowledge.toLowerCase()),
  )

  return (
    <div className="flex flex-col">
      <section className="w-full py-12">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter">Community Platform</h1>
              <p className="text-muted-foreground">
                Connect with other farmers, share knowledge, and collaborate on agricultural practices
              </p>
            </div>
            <Tabs defaultValue="discussions" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="discussions">Discussions</TabsTrigger>
                <TabsTrigger value="knowledge">Knowledge Base</TabsTrigger>
                <TabsTrigger value="experts">Expert Connect</TabsTrigger>
                <TabsTrigger value="groups">Groups</TabsTrigger>
              </TabsList>
              <TabsContent value="discussions" className="mt-6 space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <h2 className="text-2xl font-bold">Recent Discussions</h2>
                  <Button onClick={() => setShowNewDiscussionDialog(true)}>Start New Discussion</Button>
                </div>
                <div className="flex w-full max-w-sm items-center space-x-2 mb-4">
                  <Input
                    type="text"
                    placeholder="Search discussions..."
                    value={searchDiscussions}
                    onChange={(e) => setSearchDiscussions(e.target.value)}
                  />
                  <Button type="submit">
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </Button>
                </div>
                <div className="grid gap-4">
                  {filteredDiscussions.length > 0 ? (
                    filteredDiscussions.map((discussion) => (
                      <Card key={discussion.id}>
                        <CardHeader>
                          <div className="flex items-center gap-4">
                            <Avatar>
                              <AvatarImage src={discussion.author.avatar} alt={discussion.author.name} />
                              <AvatarFallback>{discussion.author.initials}</AvatarFallback>
                            </Avatar>
                            <div>
                              <CardTitle>{discussion.title}</CardTitle>
                              <CardDescription>
                                Started by {discussion.author.name} • {discussion.timeAgo}
                              </CardDescription>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-muted-foreground">{discussion.content}</p>
                        </CardContent>
                        <CardFooter className="flex justify-between">
                          <div className="flex items-center gap-4">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="flex items-center gap-1"
                              onClick={() => handleLikeDiscussion(discussion.id)}
                            >
                              <ThumbsUp
                                className={`h-4 w-4 ${discussion.liked ? "text-primary" : "text-muted-foreground"}`}
                              />
                              <span
                                className={`text-sm ${discussion.liked ? "text-primary" : "text-muted-foreground"}`}
                              >
                                {discussion.likes}
                              </span>
                            </Button>
                            <div className="flex items-center gap-1">
                              <MessageSquare className="h-4 w-4 text-muted-foreground" />
                              <span className="text-sm text-muted-foreground">{discussion.replies} replies</span>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">
                            View Discussion
                          </Button>
                        </CardFooter>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground">No discussions found matching your search.</p>
                    </div>
                  )}
                </div>
                <div className="flex justify-center">
                  <Button variant="outline">Load More Discussions</Button>
                </div>
              </TabsContent>
              <TabsContent value="knowledge" className="mt-6 space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <h2 className="text-2xl font-bold">Knowledge Base</h2>
                  <Button onClick={() => setShowNewKnowledgeDialog(true)}>Contribute Knowledge</Button>
                </div>
                <div className="flex w-full max-w-sm items-center space-x-2 mb-4">
                  <Input
                    type="text"
                    placeholder="Search knowledge base..."
                    value={searchKnowledge}
                    onChange={(e) => setSearchKnowledge(e.target.value)}
                  />
                  <Button type="submit">
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </Button>
                </div>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {filteredKnowledge.length > 0 ? (
                    filteredKnowledge.map((article) => (
                      <Card key={article.id}>
                        <CardHeader>
                          <CardTitle>{article.title}</CardTitle>
                          <CardDescription>Compiled by {article.author}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-muted-foreground">{article.content}</p>
                        </CardContent>
                        <CardFooter>
                          <Button variant="outline" size="sm">
                            Read Full Article
                          </Button>
                        </CardFooter>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-8 col-span-3">
                      <p className="text-muted-foreground">No knowledge articles found matching your search.</p>
                    </div>
                  )}
                </div>
                <div className="flex justify-center">
                  <Button variant="outline">Browse All Resources</Button>
                </div>
              </TabsContent>
              <TabsContent value="experts" className="mt-6 space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <h2 className="text-2xl font-bold">Connect with Experts</h2>
                  <Button>Request Consultation</Button>
                </div>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {experts.map((expert) => (
                    <Card key={expert.id}>
                      <CardHeader>
                        <div className="flex items-center gap-4">
                          <Avatar>
                            <AvatarImage src={expert.avatar} alt={expert.name} />
                            <AvatarFallback>{expert.initials}</AvatarFallback>
                          </Avatar>
                          <div>
                            <CardTitle>{expert.name}</CardTitle>
                            <CardDescription>{expert.role}</CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">{expert.bio}</p>
                      </CardContent>
                      <CardFooter>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedExpert(expert)
                            setShowContactExpertDialog(true)
                          }}
                        >
                          Contact Expert
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
                <div className="flex justify-center">
                  <Button variant="outline">View All Experts</Button>
                </div>
              </TabsContent>
              <TabsContent value="groups" className="mt-6 space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <h2 className="text-2xl font-bold">Community Groups</h2>
                  <Button onClick={() => setShowNewGroupDialog(true)}>Create New Group</Button>
                </div>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {groups.map((group) => (
                    <Card key={group.id}>
                      <CardHeader>
                        <div className="flex items-center gap-4">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                            <Users className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <CardTitle>{group.name}</CardTitle>
                            <CardDescription>{group.members} members</CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">{group.description}</p>
                      </CardContent>
                      <CardFooter>
                        <Button
                          variant={group.joined ? "default" : "outline"}
                          size="sm"
                          onClick={() => handleJoinGroup(group.id)}
                        >
                          {group.joined ? "Leave Group" : "Join Group"}
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
                <div className="flex justify-center">
                  <Button variant="outline">Browse All Groups</Button>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>

      {/* New Discussion Dialog */}
      <Dialog open={showNewDiscussionDialog} onOpenChange={setShowNewDiscussionDialog}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Start New Discussion</DialogTitle>
            <DialogDescription>Share your questions or insights with the community.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="discussion-title">Title</Label>
              <Input
                id="discussion-title"
                placeholder="Enter a descriptive title"
                value={newDiscussion.title}
                onChange={(e) => setNewDiscussion({ ...newDiscussion, title: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="discussion-content">Content</Label>
              <Textarea
                id="discussion-content"
                placeholder="Share your thoughts, questions, or experiences..."
                className="min-h-[150px]"
                value={newDiscussion.content}
                onChange={(e) => setNewDiscussion({ ...newDiscussion, content: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewDiscussionDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddDiscussion}>Post Discussion</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Knowledge Dialog */}
      <Dialog open={showNewKnowledgeDialog} onOpenChange={setShowNewKnowledgeDialog}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Contribute Knowledge</DialogTitle>
            <DialogDescription>Share your expertise with the community.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="knowledge-title">Title</Label>
              <Input
                id="knowledge-title"
                placeholder="Enter a descriptive title"
                value={newKnowledge.title}
                onChange={(e) => setNewKnowledge({ ...newKnowledge, title: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="knowledge-author">Author/Source</Label>
              <Input
                id="knowledge-author"
                placeholder="Your name or the source of this information"
                value={newKnowledge.author}
                onChange={(e) => setNewKnowledge({ ...newKnowledge, author: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="knowledge-content">Content</Label>
              <Textarea
                id="knowledge-content"
                placeholder="Share your knowledge or expertise..."
                className="min-h-[150px]"
                value={newKnowledge.content}
                onChange={(e) => setNewKnowledge({ ...newKnowledge, content: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewKnowledgeDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddKnowledge}>Submit</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Contact Expert Dialog */}
      <Dialog open={showContactExpertDialog} onOpenChange={setShowContactExpertDialog}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Contact Expert</DialogTitle>
            <DialogDescription>Send a message to {selectedExpert?.name || "the expert"}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="flex items-center gap-4">
              <Avatar>
                <AvatarImage src={selectedExpert?.avatar} alt={selectedExpert?.name} />
                <AvatarFallback>{selectedExpert?.initials}</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-medium">{selectedExpert?.name}</h3>
                <p className="text-sm text-muted-foreground">{selectedExpert?.role}</p>
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="expert-message">Your Message</Label>
              <Textarea
                id="expert-message"
                placeholder="Describe your question or issue..."
                className="min-h-[150px]"
                value={expertMessage}
                onChange={(e) => setExpertMessage(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowContactExpertDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleContactExpert}>Send Message</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Group Dialog */}
      <Dialog open={showNewGroupDialog} onOpenChange={setShowNewGroupDialog}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Create New Group</DialogTitle>
            <DialogDescription>Start a community group around a shared interest.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="group-name">Group Name</Label>
              <Input
                id="group-name"
                placeholder="Enter a name for your group"
                value={newGroup.name}
                onChange={(e) => setNewGroup({ ...newGroup, name: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="group-description">Description</Label>
              <Textarea
                id="group-description"
                placeholder="Describe the purpose and focus of your group..."
                className="min-h-[150px]"
                value={newGroup.description}
                onChange={(e) => setNewGroup({ ...newGroup, description: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewGroupDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateGroup}>Create Group</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
