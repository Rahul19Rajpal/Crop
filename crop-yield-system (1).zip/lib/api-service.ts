// This file simulates a backend API service using localStorage

// Types
export interface User {
  id: string
  name: string
  email: string
  password: string // In a real app, passwords would be hashed and not stored in the frontend
  role: "farmer" | "consultant" | "leader" | "agency" | "scientist"
  image?: string
  createdAt: string
}

export interface Field {
  id: number
  name: string
  area: number
  cropType: string
  userId: string
  predictedYield: number
  lastYield: number
  status: string
  soilMoisture: number
  lastWatered: string
  createdAt: string
  userId: string
}

export interface Measurement {
  id: number
  type: string
  value: string
  fieldId: number
  userId: string
  date: string
  createdAt: string
}

export interface Recommendation {
  id: number
  title: string
  description: string
  priority: "High" | "Medium" | "Low"
  crop: string
  userId: string
  implemented: boolean
  dismissed: boolean
  createdAt: string
}

export interface ContactMessage {
  id: number
  firstName: string
  lastName: string
  email: string
  userType: string
  subject: string
  message: string
  createdAt: string
}

// Helper functions
// Changed from arrow function to regular function to avoid generic syntax issues
function getItem<T>(key: string, defaultValue: T): T {
  if (typeof window === "undefined") return defaultValue
  const item = localStorage.getItem(key)
  return item ? JSON.parse(item) : defaultValue
}

function setItem<T>(key: string, value: T): void {
  if (typeof window === "undefined") return
  localStorage.setItem(key, JSON.stringify(value))
}

// Define the API object with all functions
const api = {
  // Auth
  login: async (email: string, password: string): Promise<User | null> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const users = getItem<User[]>("users", [])
    const user = users.find((u) => u.email === email && u.password === password)

    if (user) {
      // Don't return the password to the client
      const { password: _, ...userWithoutPassword } = user
      return userWithoutPassword as User
    }

    return null
  },

  register: async (name: string, email: string, password: string, role: string): Promise<User | null> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const users = getItem<User[]>("users", [])

    // Check if user already exists
    if (users.some((u) => u.email === email)) {
      return null
    }

    const newUser: User = {
      id: Math.random().toString(36).substring(2, 9),
      name,
      email,
      password,
      role: role as "farmer" | "consultant" | "leader" | "agency" | "scientist",
      image: `/placeholder.svg?height=200&width=200&text=${name[0].toUpperCase()}`,
      createdAt: new Date().toISOString(),
    }

    users.push(newUser)
    setItem("users", users)

    // Don't return the password to the client
    const { password: _, ...userWithoutPassword } = newUser
    return userWithoutPassword as User
  },

  // Fields
  getFields: async (userId: string): Promise<Field[]> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const fields = getItem<Field[]>("fields", [])
    return fields.filter((field) => field.userId === userId)
  },

  addField: async (userId: string, field: Omit<Field, "id" | "createdAt" | "userId">): Promise<Field> => {
    await new Promise((resolve) => setTimeout(resolve, 500))

    const fields = getItem<Field[]>("fields", [])

    const newField: Field = {
      ...field,
      id: Date.now(),
      createdAt: new Date().toISOString(),
      userId, // 👈 this is the key line
    }

    fields.push(newField)
    setItem("fields", fields)

    return newField
  },

  updateField: async (id: number, updates: Partial<Field>): Promise<Field | null> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const fields = getItem<Field[]>("fields", [])
    const index = fields.findIndex((field) => field.id === id)

    if (index === -1) return null

    fields[index] = { ...fields[index], ...updates }
    setItem("fields", fields)

    return fields[index]
  },

  deleteField: async (id: number): Promise<boolean> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const fields = getItem<Field[]>("fields", [])
    const filteredFields = fields.filter((field) => field.id !== id)

    if (filteredFields.length === fields.length) return false

    setItem("fields", filteredFields)
    return true
  },

  // Measurements
  getMeasurements: async (userId: string): Promise<Measurement[]> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const measurements = getItem<Measurement[]>("measurements", [])
    return measurements.filter((measurement) => measurement.userId === userId)
  },

  addMeasurement: async (measurement: Omit<Measurement, "id" | "createdAt">): Promise<Measurement> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const measurements = getItem<Measurement[]>("measurements", [])

    const newMeasurement: Measurement = {
      ...measurement,
      id: Date.now(),
      createdAt: new Date().toISOString(),
    }

    measurements.push(newMeasurement)
    setItem("measurements", measurements)

    return newMeasurement
  },

  deleteMeasurement: async (id: number): Promise<boolean> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const measurements = getItem<Measurement[]>("measurements", [])
    const filteredMeasurements = measurements.filter((measurement) => measurement.id !== id)

    if (filteredMeasurements.length === measurements.length) return false

    setItem("measurements", filteredMeasurements)
    return true
  },

  // Recommendations
  getRecommendations: async (userId: string): Promise<Recommendation[]> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const recommendations = getItem<Recommendation[]>("recommendations", [])
    return recommendations.filter((rec) => rec.userId === userId && !rec.dismissed && !rec.implemented)
  },

  implementRecommendation: async (id: number): Promise<boolean> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const recommendations = getItem<Recommendation[]>("recommendations", [])
    const index = recommendations.findIndex((rec) => rec.id === id)

    if (index === -1) return false

    recommendations[index].implemented = true
    setItem("recommendations", recommendations)

    return true
  },

  dismissRecommendation: async (id: number): Promise<boolean> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const recommendations = getItem<Recommendation[]>("recommendations", [])
    const index = recommendations.findIndex((rec) => rec.id === id)

    if (index === -1) return false

    recommendations[index].dismissed = true
    setItem("recommendations", recommendations)

    return true
  },

  // Contact
  submitContactForm: async (formData: Omit<ContactMessage, "id" | "createdAt">): Promise<boolean> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const messages = getItem<ContactMessage[]>("contactMessages", [])

    const newMessage: ContactMessage = {
      ...formData,
      id: Date.now(),
      createdAt: new Date().toISOString(),
    }

    messages.push(newMessage)
    setItem("contactMessages", messages)

    return true
  },

  // Profile
  updateProfile: async (userId: string, updates: Partial<User>): Promise<User | null> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const users = getItem<User[]>("users", [])
    const index = users.findIndex((user) => user.id === userId)

    if (index === -1) return null

    // Don't allow updating certain fields
    const { id, createdAt, ...allowedUpdates } = updates

    users[index] = { ...users[index], ...allowedUpdates }
    setItem("users", users)

    // Don't return the password to the client
    const { password, ...userWithoutPassword } = users[index]
    return userWithoutPassword as User
  },

  changePassword: async (userId: string, currentPassword: string, newPassword: string): Promise<boolean> => {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const users = getItem<User[]>("users", [])
    const index = users.findIndex((user) => user.id === userId && user.password === currentPassword)

    if (index === -1) return false

    users[index].password = newPassword
    setItem("users", users)

    return true
  },
}

// Export the API object as default
export default api
