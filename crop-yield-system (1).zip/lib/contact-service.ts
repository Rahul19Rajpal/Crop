export interface ContactFormData {
  firstName: string
  lastName: string
  email: string
  userType: string
  subject: string
  message: string
}

// Update the submitContactForm function to simulate sending an email
export async function submitContactForm(formData: ContactFormData): Promise<{ success: boolean; message: string }> {
  try {
    // Validate form data
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.message) {
      return {
        success: false,
        message: "Please fill in all required fields.",
      }
    }

    // Store the form submission in localStorage
    const submissions = getContactFormSubmissions()
    submissions.push({
      ...formData,
      id: Date.now(),
      date: new Date().toISOString(),
      status: "unread",
    })

    if (typeof window !== "undefined") {
      localStorage.setItem("contactForms", JSON.stringify(submissions))
    }

    // Simulate sending an email to infoagripredict@gmail.com
    console.log(`Email would be sent to: infoagripredict@gmail.com`)
    console.log(`From: ${formData.firstName} ${formData.lastName} <${formData.email}>`)
    console.log(`Subject: ${formData.subject || "Contact Form Submission"}`)
    console.log(`Message: ${formData.message}`)

    // In a real application, you would use an email API service here
    // For example: EmailJS, SendGrid, or a custom backend endpoint

    // Simulate API call success
    return {
      success: true,
      message:
        "Thank you for your message! We'll get back to you soon. A confirmation has been sent to infoagripredict@gmail.com.",
    }
  } catch (error) {
    console.error("Contact form submission error:", error)
    return {
      success: false,
      message: "An unexpected error occurred. Please try again.",
    }
  }
}

// Function to retrieve stored contact form submissions
export function getContactFormSubmissions(): any[] {
  if (typeof window === "undefined") return []

  const storedForms = localStorage.getItem("contactForms")
  return storedForms ? JSON.parse(storedForms) : []
}
