function getTextNodes(node: Node): Text[] {
  const textNodes: Text[] = []

  function traverse(currentNode: Node) {
    if (currentNode.nodeType === Node.TEXT_NODE && currentNode.nodeValue && currentNode.nodeValue.trim().length > 0) {
      textNodes.push(currentNode as Text)
    } else {
      currentNode.childNodes.forEach(traverse)
    }
  }

  traverse(node)
  return textNodes
}

export function applyPageTranslation(language: string): void {
  if (typeof document === "undefined") return

  const languagePrefixes: Record<string, string> = {
    hi: "[हिन्दी]",
    ta: "[தமிழ்]",
  }

  const prefix = languagePrefixes[language]
  const allPrefixesRegex = /^\[(हिन्दी|தமிழ்)\]\s*/

  const textNodes = getTextNodes(document.body)

  textNodes.forEach((node) => {
    const original = node.nodeValue?.trim()
    if (!original || original.length <= 1) return

    // Remove any existing language prefix
    const cleanText = original.replace(allPrefixesRegex, "")

    // If English, restore original text (without any prefix)
    if (language === "en") {
      node.nodeValue = cleanText
    } else if (!original.startsWith(prefix)) {
      node.nodeValue = `${prefix} ${cleanText}`
    }
  })
}
