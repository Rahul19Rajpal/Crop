export interface SoilData {
  moisture: number
  ph: number
  nitrogen: number
  phosphorus: number
  potassium: number
  organicMatter: number
}

// This function simulates fetching soil data based on location
export async function getSoilData(location: string): Promise<SoilData> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Generate deterministic but different values based on location string
  const locationHash = hashString(location.toLowerCase())
  const randomSeed = locationHash / 1000000

  // Generate soil data with some variation
  return {
    moisture: Math.round(40 + randomSeed * 50), // 40-90%
    ph: Math.round((5.5 + randomSeed * 3) * 10) / 10, // 5.5-8.5
    nitrogen: Math.round(20 + randomSeed * 60), // 20-80 ppm
    phosphorus: Math.round(15 + randomSeed * 45), // 15-60 ppm
    potassium: Math.round(150 + randomSeed * 250), // 150-400 ppm
    organicMatter: Math.round((1 + randomSeed * 8) * 10) / 10, // 1-9%
  }
}

// Simple hash function for strings
function hashString(str: string): number {
  let hash = 0
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i)
    hash = (hash << 5) - hash + char
    hash = hash & hash // Convert to 32bit integer
  }
  return Math.abs(hash)
}
