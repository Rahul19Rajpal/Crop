// Weather API service

export interface WeatherForecast {
  day: string
  temp: number
  condition: string
  icon: string // full image URL to be used in <img src="..." />
  precipitation: number // percentage (e.g., 60)
}

const API_KEY = "319d1b70266ac8fd58b2db69082cb8a6" // 🔑 Replace with your OpenWeatherMap API key

// Mock weather data to use when API key is not available
const mockWeatherData: WeatherForecast[] = [
  {
    day: "Today",
    temp: 28,
    condition: "Sunny",
    icon: "https://openweathermap.org/img/wn/01d@2x.png",
    precipitation: 0,
  },
  {
    day: "Tomorrow",
    temp: 26,
    condition: "Partly Cloudy",
    icon: "https://openweathermap.org/img/wn/02d@2x.png",
    precipitation: 10,
  },
  {
    day: "Wednesday",
    temp: 24,
    condition: "Cloudy",
    icon: "https://openweathermap.org/img/wn/03d@2x.png",
    precipitation: 30,
  },
  {
    day: "Thursday",
    temp: 22,
    condition: "Light Rain",
    icon: "https://openweathermap.org/img/wn/10d@2x.png",
    precipitation: 60,
  },
  {
    day: "Friday",
    temp: 25,
    condition: "Sunny",
    icon: "https://openweathermap.org/img/wn/01d@2x.png",
    precipitation: 0,
  },
]

// This function fetches real weather data from OpenWeatherMap API or returns mock data if API key is not available
export async function getWeatherForecast(city = "New York"): Promise<WeatherForecast[]> {
  try {
    // If no API key is provided, return mock data
    if (!API_KEY) {
      console.log("No API key provided, using mock weather data")
      return generateMockWeatherData(city)
    }

    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/forecast?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`,
    )

    if (!response.ok) {
      throw new Error(`Failed to fetch weather data: ${response.statusText}`)
    }

    const data = await response.json()

    // Group 3-hour forecast data into days
    const dailyMap: Record<string, WeatherForecast[]> = {}

    for (const entry of data.list) {
      const date = new Date(entry.dt_txt)
      const dayKey = date.toDateString()

      if (!dailyMap[dayKey]) dailyMap[dayKey] = []

      dailyMap[dayKey].push({
        day: "", // Will set later
        temp: entry.main.temp,
        condition: entry.weather[0].main,
        icon: `https://openweathermap.org/img/wn/${entry.weather[0].icon}@2x.png`,
        precipitation: entry.pop ? Math.round(entry.pop * 100) : 0,
      })
    }

    // Build final 5-day summary
    const forecast: WeatherForecast[] = []

    Object.entries(dailyMap)
      .slice(0, 5)
      .forEach(([dateStr, values], index) => {
        const temps = values.map((v) => v.temp)
        const avgTemp = Math.round(temps.reduce((a, b) => a + b, 0) / temps.length)

        // Get most common condition
        const conditionCount: Record<string, number> = {}
        values.forEach((v) => {
          conditionCount[v.condition] = (conditionCount[v.condition] || 0) + 1
        })
        const mostFrequent = Object.entries(conditionCount).sort((a, b) => b[1] - a[1])[0][0]

        // Use icon from the most frequent condition (or fallback)
        const iconEntry = values.find((v) => v.condition === mostFrequent)
        const icon = iconEntry ? iconEntry.icon : "https://openweathermap.org/img/wn/01d@2x.png"

        const avgPrecip = Math.round(values.reduce((a, b) => a + b.precipitation, 0) / values.length)

        const dateObj = new Date(dateStr)
        const dayName =
          index === 0 ? "Today" : index === 1 ? "Tomorrow" : dateObj.toLocaleDateString("en-US", { weekday: "long" })

        forecast.push({
          day: dayName,
          temp: avgTemp,
          condition: mostFrequent,
          icon,
          precipitation: avgPrecip,
        })
      })

    return forecast
  } catch (error) {
    console.error("Error fetching weather data:", error)
    // Return mock data as fallback
    return generateMockWeatherData(city)
  }
}

// Generate deterministic but different mock weather data based on city name
function generateMockWeatherData(city: string): WeatherForecast[] {
  // Create a simple hash of the city name to get deterministic but different values
  const hash = city.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0) % 100

  // Clone the mock data to avoid modifying the original
  const cityWeather = [...mockWeatherData]

  // Adjust temperature and precipitation based on city hash
  cityWeather.forEach((forecast, index) => {
    // Adjust temperature by -5 to +5 degrees based on city hash
    forecast.temp = Math.round(forecast.temp + ((hash % 10) - 5))

    // Adjust precipitation by -10 to +10 percentage points
    forecast.precipitation = Math.max(0, Math.min(100, forecast.precipitation + ((hash % 20) - 10)))

    // Potentially change condition based on precipitation
    if (forecast.precipitation > 70) {
      forecast.condition = "Heavy Rain"
      forecast.icon = "https://openweathermap.org/img/wn/10d@2x.png"
    } else if (forecast.precipitation > 40) {
      forecast.condition = "Light Rain"
      forecast.icon = "https://openweathermap.org/img/wn/09d@2x.png"
    } else if (forecast.precipitation > 20) {
      forecast.condition = "Cloudy"
      forecast.icon = "https://openweathermap.org/img/wn/03d@2x.png"
    } else if (forecast.precipitation > 10) {
      forecast.condition = "Partly Cloudy"
      forecast.icon = "https://openweathermap.org/img/wn/02d@2x.png"
    } else {
      forecast.condition = "Sunny"
      forecast.icon = "https://openweathermap.org/img/wn/01d@2x.png"
    }
  })

  return cityWeather
}

// Get list of popular cities
export function getPopularCities(): string[] {
  return [
    "New York",
    "London",
    "Tokyo",
    "Paris",
    "Sydney",
    "Berlin",
    "Moscow",
    "Beijing",
    "Rio de Janeiro",
    "Cairo",
    "Mumbai",
    "Toronto",
    "Chicago",
    "Los Angeles",
    "San Francisco",
  ]
}

// Get weather for custom city (reuse main function)
export async function getWeatherForCity(city: string): Promise<WeatherForecast[]> {
  return getWeatherForecast(city)
}
