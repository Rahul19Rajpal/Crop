"use client"

import { createContext, useContext, useState, type ReactNode, useMemo, useCallback } from "react"

// Add translateText function to the LanguageContextType
interface LanguageContextType {
  language: string
  setLanguage: (language: string) => void
  t: (key: string) => string
  translateText: (text: string) => string
}

// Create the context with default values including translateText
const LanguageContext = createContext<LanguageContextType>({
  language: "en",
  setLanguage: () => {},
  t: (key) => key,
  translateText: (text) => text,
})

// Update the useLanguage hook to include a translateText function for dynamic content
export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

// Export the LanguageProvider component
export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState("en")

  // Simple translation function for demonstration
  const t = useMemo(() => {
    const translations: Record<string, Record<string, string>> = {
      en: {
        Home: "Home",
        About: "About",
        Features: "Features",
        Dashboard: "Dashboard",
        Community: "Community",
        Contact: "Contact",
        Login: "Login",
        Register: "Register",
        Profile: "Profile",
        Settings: "Settings",
        Logout: "Logout",
        Language: "Language",
        "dashboard.welcome": "Welcome",
        "dashboard.overview": "Overview",
        "dashboard.predictions": "Predictions",
        "dashboard.recommendations": "Recommendations",
        "dashboard.data": "My Data",
        "dashboard.totalFields": "Total Fields",
        "dashboard.activeCrops": "Active Crops",
        "dashboard.predictedYield": "Predicted Yield",
        "dashboard.weatherForecast": "Weather Forecast",
        "profile.general": "General",
        "profile.security": "Security",
        "profile.notifications": "Notifications",
        "profile.language": "Language",
        "language.select": "Select Language",
        "language.english": "English",
        "language.hindi": "हिन्दी (Hindi)",
        "language.tamil": "தமிழ் (Tamil)",
      },
      hi: {
        Home: "मुख पृष्ठ",
        About: "के बारे में",
        Features: "सुविधाएँ",
        Dashboard: "डैशबोर्ड",
        Community: "समुदाय",
        Contact: "संपर्क करें",
        Login: "लॉगिन",
        Register: "पंजीकरण",
        Profile: "प्रोफ़ाइल",
        Settings: "सेटिंग्स",
        Logout: "लॉग आउट",
        Language: "भाषा",
        "dashboard.welcome": "स्वागत है",
        "dashboard.overview": "अवलोकन",
        "dashboard.predictions": "भविष्यवाणियां",
        "dashboard.recommendations": "सिफारिशें",
        "dashboard.data": "मेरा डेटा",
        "dashboard.totalFields": "कुल खेत",
        "dashboard.activeCrops": "सक्रिय फसलें",
        "dashboard.predictedYield": "अनुमानित उपज",
        "dashboard.weatherForecast": "मौसम का पूर्वानुमान",
        "profile.general": "सामान्य",
        "profile.security": "सुरक्षा",
        "profile.notifications": "सूचनाएँ",
        "profile.language": "भाषा",
        "language.select": "भाषा चुनें",
        "language.english": "अंग्रेज़ी",
        "language.hindi": "हिन्दी",
        "language.tamil": "तमिल",
      },
      ta: {
        Home: "முகப்பு",
        About: "பற்றி",
        Features: "அம்சங்கள்",
        Dashboard: "டாஷ்போர்டு",
        Community: "சமூகம்",
        Contact: "தொடர்பு கொள்ளவும்",
        Login: "உள்நுழைவு",
        Register: "பதிவு",
        Profile: "சுயவிவரம்",
        Settings: "அமைப்புகள்",
        Logout: "வெளியேறு",
        Language: "மொழி",
        "dashboard.welcome": "வரவேற்கிறோம்",
        "dashboard.overview": "கண்ணோட்டம்",
        "dashboard.predictions": "கணிப்புகள்",
        "dashboard.recommendations": "பரிந்துரைகள்",
        "dashboard.data": "எனது தரவு",
        "dashboard.totalFields": "மொத்த வயல்கள்",
        "dashboard.activeCrops": "செயலில் உள்ள பயிர்கள்",
        "dashboard.predictedYield": "கணிக்கப்பட்ட விளைச்சல்",
        "dashboard.weatherForecast": "வானிலை முன்னறிவிப்பு",
        "profile.general": "பொது",
        "profile.security": "பாதுகாப்பு",
        "profile.notifications": "அறிவிப்புகள்",
        "profile.language": "மொழி",
        "language.select": "மொழி தேர்வு செய்யவும்",
        "language.english": "ஆங்கிலம்",
        "language.hindi": "ஹிந்தி",
        "language.tamil": "தமிழ்",
      },
    }

    return (key: string) => {
      if (translations[language] && translations[language][key]) {
        return translations[language][key]
      }
      return key
    }
  }, [language])

  // Add a function to translate arbitrary text
  const translateText = useCallback(
    (text: string) => {
      if (language === "en") return text

      // For demo purposes, we'll simulate translation by adding a prefix
      // In a real app, you would use a translation API here
      try {
        // Simulate API call for translation
        if (language === "hi") {
          return `[हिन्दी] ${text}`
        } else if (language === "ta") {
          return `[தமிழ்] ${text}`
        }
        return text
      } catch (error) {
        console.error("Translation error:", error)
        return text
      }
    },
    [language],
  )

  return (
    <LanguageContext.Provider value={{ language, setLanguage: setLanguageState, t, translateText }}>
      {children}
    </LanguageContext.Provider>
  )
}
