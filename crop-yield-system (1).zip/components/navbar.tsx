"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { useAuth } from "@/components/auth-provider"
import { useLanguage } from "@/components/language-provider"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Globe } from "lucide-react"

// Import the translation utility
import { applyPageTranslation } from "@/lib/translation-utils"

export default function Navbar() {
  const pathname = usePathname()
  const { user, logout } = useAuth()
  const { t, language, setLanguage } = useLanguage()

  // In the language selection handler, add the page translation
  const handleLanguageChange = (value: string) => {
    setLanguage(value)
    // Apply translation to the entire page
    setTimeout(() => applyPageTranslation(value), 100)
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-xl font-bold text-green-600">AgriPredict</span>
          </Link>
          <nav className="hidden md:flex gap-6 ml-6">
            <Link
              href="/"
              className={`text-sm font-medium transition-colors hover:text-green-600 ${
                pathname === "/" ? "text-green-600" : "text-foreground/60"
              }`}
            >
              {t("Home")}
            </Link>
            <Link
              href="/about"
              className={`text-sm font-medium transition-colors hover:text-green-600 ${
                pathname === "/about" ? "text-green-600" : "text-foreground/60"
              }`}
            >
              {t("About")}
            </Link>
            <Link
              href="/features"
              className={`text-sm font-medium transition-colors hover:text-green-600 ${
                pathname === "/features" ? "text-green-600" : "text-foreground/60"
              }`}
            >
              {t("Features")}
            </Link>
            <Link
              href="/dashboard"
              className={`text-sm font-medium transition-colors hover:text-green-600 ${
                pathname === "/dashboard" ? "text-green-600" : "text-foreground/60"
              }`}
            >
              {t("Dashboard")}
            </Link>
            <Link
              href="/community"
              className={`text-sm font-medium transition-colors hover:text-green-600 ${
                pathname === "/community" ? "text-green-600" : "text-foreground/60"
              }`}
            >
              {t("Community")}
            </Link>
            <Link
              href="/contact"
              className={`text-sm font-medium transition-colors hover:text-green-600 ${
                pathname === "/contact" ? "text-green-600" : "text-foreground/60"
              }`}
            >
              {t("Contact")}
            </Link>
          </nav>
        </div>
        <div className="flex items-center gap-2">
          <ModeToggle />

          {/* Language Selector */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <Globe className="h-5 w-5" />
                <span className="sr-only">{t("Language")}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>{t("language.select")}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => handleLanguageChange("en")}>{t("language.english")}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleLanguageChange("hi")}>{t("language.hindi")}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleLanguageChange("ta")}>{t("language.tamil")}</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.image} alt={user.name} />
                    <AvatarFallback>{user.name[0]}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user.name}</p>
                    <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/profile">{t("Profile")}</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/dashboard">{t("Dashboard")}</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/profile">{t("Settings")}</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="cursor-pointer"
                  onClick={() => {
                    logout()
                    window.location.href = "/"
                  }}
                >
                  {t("Logout")}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="ghost" asChild>
                <Link href="/login">{t("Login")}</Link>
              </Button>
              <Button asChild>
                <Link href="/register">{t("Register")}</Link>
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
