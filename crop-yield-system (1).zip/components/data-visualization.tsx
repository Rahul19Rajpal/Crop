"use client"

import type React from "react"
import { useEffect, useRef, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface ChartProps {
  type: "bar" | "line" | "pie"
  data: {
    labels: string[]
    datasets: {
      label: string
      data: number[]
      backgroundColor?: string | string[]
      borderColor?: string
      borderWidth?: number
      fill?: boolean
    }[]
  }
  options?: any
}

const Chart: React.FC<ChartProps> = ({ type, data, options = {} }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const chartInstanceRef = useRef<any>(null)
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 })
  const containerRef = useRef<HTMLDivElement>(null)

  // Handle resize to make charts responsive
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.clientWidth,
          height: 300, // Fixed height
        })
      }
    }

    handleResize() // Initial size
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  useEffect(() => {
    if (!canvasRef.current || dimensions.width === 0) return

    const ctx = canvasRef.current.getContext("2d")
    if (!ctx) return

    // Clear previous chart if it exists
    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy()
    }

    // Set canvas dimensions
    canvasRef.current.width = dimensions.width
    canvasRef.current.height = dimensions.height

    // Simple chart rendering using canvas
    const canvas = canvasRef.current
    const width = canvas.width
    const height = canvas.height
    ctx.clearRect(0, 0, width, height)

    if (type === "bar") {
      renderBarChart(ctx, data, width, height)
    } else if (type === "line") {
      renderLineChart(ctx, data, width, height)
    } else if (type === "pie") {
      renderPieChart(ctx, data, width, height)
    }
  }, [type, data, options, dimensions])

  const renderBarChart = (ctx: CanvasRenderingContext2D, data: any, width: number, height: number) => {
    const labels = data.labels
    const dataset = data.datasets[0]
    const barWidth = Math.min(50, (width - 80) / labels.length) // Limit max bar width
    const barSpacing = (width - 80 - barWidth * labels.length) / (labels.length + 1)
    const maxValue = Math.max(...dataset.data) * 1.1 || 1 // Prevent division by zero

    // Draw background
    ctx.fillStyle = "rgba(255, 255, 255, 0.1)"
    ctx.fillRect(40, 20, width - 60, height - 60)

    // Draw axes
    ctx.beginPath()
    ctx.strokeStyle = "#888"
    ctx.lineWidth = 1
    ctx.moveTo(40, 20)
    ctx.lineTo(40, height - 40)
    ctx.lineTo(width - 20, height - 40)
    ctx.stroke()

    // Draw grid lines
    ctx.beginPath()
    ctx.strokeStyle = "#eee"
    ctx.lineWidth = 0.5
    for (let i = 1; i <= 5; i++) {
      const y = height - 40 - (i * (height - 60)) / 5
      ctx.moveTo(40, y)
      ctx.lineTo(width - 20, y)
    }
    ctx.stroke()

    // Draw bars
    labels.forEach((label: string, index: number) => {
      const x = 40 + barSpacing + index * (barWidth + barSpacing)
      const barHeight = (dataset.data[index] / maxValue) * (height - 60)

      // Draw bar
      ctx.fillStyle = Array.isArray(dataset.backgroundColor)
        ? dataset.backgroundColor[index]
        : dataset.backgroundColor || "#4ade80"
      ctx.fillRect(x, height - 40 - barHeight, barWidth, barHeight)

      // Draw label
      ctx.fillStyle = "#888"
      ctx.font = "10px Arial"
      ctx.textAlign = "center"
      ctx.fillText(label, x + barWidth / 2, height - 25)

      // Draw value
      ctx.fillStyle = "#333"
      ctx.fillText(dataset.data[index].toString(), x + barWidth / 2, height - 45 - barHeight)
    })

    // Draw title
    ctx.fillStyle = "#333"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.fillText(dataset.label, width / 2, 15)
  }

  const renderLineChart = (ctx: CanvasRenderingContext2D, data: any, width: number, height: number) => {
    const labels = data.labels
    const dataset = data.datasets[0]
    const maxValue = Math.max(...dataset.data) * 1.1 || 1 // Prevent division by zero
    const pointWidth = (width - 60) / (labels.length - 1 || 1) // Prevent division by zero

    // Draw background
    ctx.fillStyle = "rgba(255, 255, 255, 0.1)"
    ctx.fillRect(40, 20, width - 60, height - 60)

    // Draw axes
    ctx.beginPath()
    ctx.strokeStyle = "#888"
    ctx.lineWidth = 1
    ctx.moveTo(40, 20)
    ctx.lineTo(40, height - 40)
    ctx.lineTo(width - 20, height - 40)
    ctx.stroke()

    // Draw grid lines
    ctx.beginPath()
    ctx.strokeStyle = "#eee"
    ctx.lineWidth = 0.5
    for (let i = 1; i <= 5; i++) {
      const y = height - 40 - (i * (height - 60)) / 5
      ctx.moveTo(40, y)
      ctx.lineTo(width - 20, y)
    }
    ctx.stroke()

    // Draw line
    ctx.beginPath()
    dataset.data.forEach((value: number, index: number) => {
      const x = 40 + index * pointWidth
      const y = height - 40 - (value / maxValue) * (height - 60)

      if (index === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    })
    ctx.strokeStyle = dataset.borderColor || "#4ade80"
    ctx.lineWidth = 2
    ctx.stroke()

    // Fill area under the line if fill is true
    if (dataset.fill) {
      ctx.lineTo(40 + (labels.length - 1) * pointWidth, height - 40)
      ctx.lineTo(40, height - 40)
      ctx.closePath()
      ctx.fillStyle = "rgba(74, 222, 128, 0.1)"
      ctx.fill()
    }

    // Draw points and labels
    dataset.data.forEach((value: number, index: number) => {
      const x = 40 + index * pointWidth
      const y = height - 40 - (value / maxValue) * (height - 60)

      // Draw point
      ctx.fillStyle = dataset.borderColor || "#4ade80"
      ctx.beginPath()
      ctx.arc(x, y, 4, 0, Math.PI * 2)
      ctx.fill()

      // Draw label
      ctx.fillStyle = "#888"
      ctx.font = "10px Arial"
      ctx.textAlign = "center"
      ctx.fillText(labels[index], x, height - 25)

      // Draw value
      ctx.fillStyle = "#333"
      ctx.fillText(value.toString(), x, y - 10)
    })

    // Draw title
    ctx.fillStyle = "#333"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.fillText(dataset.label, width / 2, 15)
  }

  const renderPieChart = (ctx: CanvasRenderingContext2D, data: any, width: number, height: number) => {
    const dataset = data.datasets[0]
    const total = dataset.data.reduce((sum: number, value: number) => sum + value, 0) || 1 // Prevent division by zero
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(centerX, centerY) - 60

    let startAngle = 0

    // Draw pie slices
    dataset.data.forEach((value: number, index: number) => {
      const sliceAngle = (value / total) * 2 * Math.PI

      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle)
      ctx.closePath()

      ctx.fillStyle = Array.isArray(dataset.backgroundColor)
        ? dataset.backgroundColor[index]
        : dataset.backgroundColor || "#4ade80"
      ctx.fill()

      // Draw label line
      const midAngle = startAngle + sliceAngle / 2
      const labelRadius = radius * 1.2
      const labelX = centerX + Math.cos(midAngle) * labelRadius
      const labelY = centerY + Math.sin(midAngle) * labelRadius

      ctx.beginPath()
      ctx.moveTo(centerX + Math.cos(midAngle) * radius, centerY + Math.sin(midAngle) * radius)
      ctx.lineTo(labelX, labelY)
      ctx.strokeStyle = "#888"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw label
      const percent = Math.round((value / total) * 100)
      ctx.fillStyle = "#333"
      ctx.font = "12px Arial"
      ctx.textAlign = midAngle < Math.PI ? "left" : "right"
      ctx.textBaseline = "middle"
      ctx.fillText(`${data.labels[index]} (${percent}%)`, labelX + (midAngle < Math.PI ? 5 : -5), labelY)

      startAngle += sliceAngle
    })

    // Draw title
    ctx.fillStyle = "#333"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText(dataset.label, centerX, 15)
  }

  return (
    <div ref={containerRef} className="w-full h-[300px]">
      <canvas ref={canvasRef} className="w-full h-full" />
    </div>
  )
}

interface DataVisualizationProps {
  userFields?: any[]
}

export default function DataVisualization({ userFields }: DataVisualizationProps) {
  // Generate yield data
  const generateYieldData = () => {
    return {
      labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      datasets: [
        {
          label: "Crop Yield Trends (tons/acre)",
          data: [4.2, 4.3, 4.5, 4.8, 5.2, 5.7, 6.1, 6.3, 6.2, 5.9, 5.5, 5.0],
          borderColor: "#4ade80",
          backgroundColor: "rgba(74, 222, 128, 0.2)",
          borderWidth: 2,
          fill: true,
        },
      ],
    }
  }

  // Generate crop distribution data based on user fields
  const generateCropDistributionData = () => {
    if (!userFields || userFields.length === 0) {
      return {
        labels: ["Wheat", "Corn", "Soybeans", "Rice", "Other"],
        datasets: [
          {
            label: "Crop Distribution by Acreage",
            data: [45, 30, 25, 15, 5],
            backgroundColor: [
              "rgba(74, 222, 128, 0.8)",
              "rgba(251, 191, 36, 0.8)",
              "rgba(59, 130, 246, 0.8)",
              "rgba(139, 92, 246, 0.8)",
              "rgba(239, 68, 68, 0.8)",
            ],
            borderWidth: 1,
          },
        ],
      }
    }

    // Count fields by crop type
    const cropCounts: Record<string, number> = {}
    userFields.forEach((field) => {
      if (cropCounts[field.name]) {
        cropCounts[field.name] += field.area
      } else {
        cropCounts[field.name] = field.area
      }
    })

    // Convert to arrays for chart
    const labels = Object.keys(cropCounts)
    const data = Object.values(cropCounts)

    // Generate colors
    const colors = [
      "rgba(74, 222, 128, 0.8)",
      "rgba(251, 191, 36, 0.8)",
      "rgba(59, 130, 246, 0.8)",
      "rgba(139, 92, 246, 0.8)",
      "rgba(239, 68, 68, 0.8)",
      "rgba(236, 72, 153, 0.8)",
      "rgba(14, 165, 233, 0.8)",
      "rgba(168, 85, 247, 0.8)",
    ]

    return {
      labels,
      datasets: [
        {
          label: "Crop Distribution by Acreage",
          data,
          backgroundColor: labels.map((_, i) => colors[i % colors.length]),
          borderWidth: 1,
        },
      ],
    }
  }

  // Generate soil moisture data based on user fields
  const generateSoilMoistureData = () => {
    if (!userFields || userFields.length === 0) {
      return {
        labels: ["Field 1", "Field 2", "Field 3", "Field 4", "Field 5", "Field 6"],
        datasets: [
          {
            label: "Soil Moisture Levels (%)",
            data: [68, 42, 71, 85, 55, 63],
            backgroundColor: [
              "rgba(74, 222, 128, 0.8)",
              "rgba(239, 68, 68, 0.8)",
              "rgba(74, 222, 128, 0.8)",
              "rgba(74, 222, 128, 0.8)",
              "rgba(251, 191, 36, 0.8)",
              "rgba(74, 222, 128, 0.8)",
            ],
            borderWidth: 1,
          },
        ],
      }
    }

    // Extract field names and moisture levels
    const labels = userFields.map((field) => field.name)
    const data = userFields.map((field) => field.soilMoisture)

    // Generate colors based on moisture levels (red for low, green for good)
    const colors = data.map((moisture) => {
      if (moisture < 30) return "rgba(239, 68, 68, 0.8)" // Red for very dry
      if (moisture < 50) return "rgba(251, 191, 36, 0.8)" // Yellow for somewhat dry
      if (moisture > 80) return "rgba(59, 130, 246, 0.8)" // Blue for very wet
      return "rgba(74, 222, 128, 0.8)" // Green for good moisture
    })

    return {
      labels,
      datasets: [
        {
          label: "Soil Moisture Levels (%)",
          data,
          backgroundColor: colors,
          borderWidth: 1,
        },
      ],
    }
  }

  const yieldData = generateYieldData()
  const cropDistributionData = generateCropDistributionData()
  const soilMoistureData = generateSoilMoistureData()

  return (
    <div className="space-y-6">
      <Tabs defaultValue="yield" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="yield">Yield Trends</TabsTrigger>
          <TabsTrigger value="distribution">Crop Distribution</TabsTrigger>
          <TabsTrigger value="moisture">Soil Moisture</TabsTrigger>
        </TabsList>
        <TabsContent value="yield" className="mt-6">
          <Card className="border-green-100 dark:border-green-900/50">
            <CardHeader>
              <CardTitle>Crop Yield Trends</CardTitle>
              <CardDescription>Historical and predicted crop yields over time</CardDescription>
            </CardHeader>
            <CardContent>
              <Chart type="line" data={yieldData} />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="distribution" className="mt-6">
          <Card className="border-green-100 dark:border-green-900/50">
            <CardHeader>
              <CardTitle>Crop Distribution</CardTitle>
              <CardDescription>Current crop allocation across your fields</CardDescription>
            </CardHeader>
            <CardContent>
              <Chart type="pie" data={cropDistributionData} />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="moisture" className="mt-6">
          <Card className="border-green-100 dark:border-green-900/50">
            <CardHeader>
              <CardTitle>Soil Moisture Levels</CardTitle>
              <CardDescription>Current moisture levels across different fields</CardDescription>
            </CardHeader>
            <CardContent>
              <Chart type="bar" data={soilMoistureData} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
