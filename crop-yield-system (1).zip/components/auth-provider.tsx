"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"

// Import the API service as default
import api from "@/lib/api-service"

type User = {
  id: string
  name: string
  email: string
  role: "farmer" | "consultant" | "leader" | "agency" | "scientist"
  image?: string
} | null

type AuthContextType = {
  user: User
  login: (email: string, password: string) => Promise<User | null>
  register: (name: string, email: string, password: string, role: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  login: async () => null,
  register: async () => false,
  logout: () => {},
  isLoading: true,
})

export const useAuth = () => useContext(AuthContext)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is stored in localStorage
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setIsLoading(false)
  }, [])

  // Update the login function to handle demo accounts
  const login = async (email: string, password: string): Promise<User | null> => {
    setIsLoading(true)

    try {
      // Special handling for demo accounts
      const demoAccounts = [
        "farmer@example.com",
        "consultant@example.com",
        "leader@example.com",
        "gov@example.com",
        "scientist@example.com",
      ]

      if (demoAccounts.includes(email)) {
        // For demo accounts, create a user object directly
        const role = email.split("@")[0]
        const demoUser = {
          id: `demo-${role}`,
          name: `Demo ${role.charAt(0).toUpperCase() + role.slice(1)}`,
          email: email,
          role: role as "farmer" | "consultant" | "leader" | "agency" | "scientist",
          image: `/placeholder.svg?height=200&width=200&text=${role[0].toUpperCase()}`,
        }

        setUser(demoUser)
        localStorage.setItem("user", JSON.stringify(demoUser))

        // Initialize user data in localStorage if not already present
        initializeUserData(demoUser.id)

        setIsLoading(false)
        return demoUser
      }

      // Regular login flow for non-demo accounts
      const user = await api.login(email, password)

      if (user) {
        setUser(user)
        localStorage.setItem("user", JSON.stringify(user))

        // Initialize user data in localStorage if not already present
        initializeUserData(user.id)

        return user
      }

      return null
    } catch (error) {
      console.error("Login error:", error)
      return null
    } finally {
      setIsLoading(false)
    }
  }

  // Update the register function to use the API
  const register = async (name: string, email: string, password: string, role: string) => {
    setIsLoading(true)

    try {
      const user = await api.register(name, email, password, role)

      if (user) {
        setUser(user)
        localStorage.setItem("user", JSON.stringify(user))
        return true
      }

      return false
    } catch (error) {
      console.error("Registration error:", error)
      return false
    } finally {
      setIsLoading(false)
    }
  }
  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  // Add this helper function to initialize user data
  const initializeUserData = (userId: string) => {
    // Check if user fields exist
    if (!localStorage.getItem(`userFields_${userId}`)) {
      localStorage.setItem(`userFields_${userId}`, JSON.stringify([]))
    }

    // Check if user measurements exist
    if (!localStorage.getItem(`userMeasurements_${userId}`)) {
      localStorage.setItem(`userMeasurements_${userId}`, JSON.stringify([]))
    }

    // Check if user recommendations exist
    if (!localStorage.getItem(`userRecommendations_${userId}`)) {
      localStorage.setItem(`userRecommendations_${userId}`, JSON.stringify([]))
    }
  }

  return <AuthContext.Provider value={{ user, login, register, logout, isLoading }}>{children}</AuthContext.Provider>
}
